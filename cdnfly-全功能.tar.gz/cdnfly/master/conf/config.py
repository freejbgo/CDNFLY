# -*- coding: utf-8 -*-

AES_KEY='SoOS2zdavRkRtyuU' #安装时生成一个随机的

MYSQL_IP="127.0.0.1"
MYSQL_PORT=3306
MYSQL_USER='root'
MYSQL_PASS='@cdnflypass'
MYSQL_DB='cdn'

LOG_IP="127.0.0.1"
LOG_PORT=9200
LOG_USER="elastic"
LOG_PWD="VpCXYWmleX"

VERSION_NAME="v5.1.13"
VERSION_NUM=50113
CODEPAY_GATEWAY="https://api.xiuxiu888.com/creat_order/"

FORCE_SSL=False
INDEX_PATH="/console/index.html"

