# -*- coding: utf-8 -*-
import hashlib
import hmac
import json
import sys
import time

sys.path.append("/opt/cdnfly/master/")

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None


def _unicode():
    try:
        return unicode
    except NameError:
        return str


def _text(value):
    text = _unicode()
    if value is None:
        return text("")
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text(value)


def _bytes(value):
    text = _unicode()
    if isinstance(value, text):
        return value.encode("utf-8")
    if isinstance(value, bytes):
        return value
    return str(value).encode("utf-8")


def _plain(value):
    text = _unicode()
    if isinstance(value, dict):
        return dict((_plain(key), _plain(item)) for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        try:
            return _text(value)
        except Exception:
            return value.decode("latin-1")
    return value


def _dump(value):
    return _bytes(json.dumps(_plain(value), separators=(",", ":")))


def _show(value):
    try:
        return _text(value)
    except Exception:
        try:
            return _text(repr(value))
        except Exception:
            return u""


def _load_auth(auth):
    if isinstance(auth, dict):
        return auth
    try:
        loaded = json.loads(auth)
    except (ValueError, TypeError):
        raise ValueError(u"传入的验证信息非json")
    if not isinstance(loaded, dict):
        raise ValueError(u"传入的验证信息非json")
    return loaded


def _http_error(url, exc):
    name = exc.__class__.__name__
    if name in ("ConnectTimeout", "ConnectTimeoutError"):
        return None, u"url:{url} 连接超时".format(url=url)
    if name in ("Timeout", "ReadTimeout"):
        return None, u"url:{url} 读取超时".format(url=url)
    if name in ("ConnectionError", "ProtocolError"):
        return None, u"url:{url} 连接错误".format(url=url)
    return None, u"url:{url} {err}".format(url=url, err=_show(exc))


def _as_int(value):
    try:
        return int(value), None
    except (TypeError, ValueError):
        return None, u"记录编号不正确"


def _record_value(record_type, value):
    if value is None or record_type not in ("CNAME", "NS", "MX", "SRV"):
        return value
    text = _text(value)
    if len(text) > 1 and text.endswith(u"."):
        return text[:-1]
    return value


class Dns(_dns_base):
    host = "dnspod.tencentcloudapi.com"
    service = "dnspod"
    version = "2021-03-23"
    default_line_name = u"默认"

    def __init__(self, auth):
        auth = _load_auth(auth)
        secret_id = _text(auth.get("id") or auth.get("secret_id")).strip()
        secret_key = _text(auth.get("token") or auth.get("secret_key")).strip()
        if not secret_id:
            raise ValueError(u"auth中找不到id")
        if not secret_key:
            raise ValueError(u"auth中找不到token")
        self.secret_id = secret_id
        self.secret_key = secret_key

    def _sign(self, action, payload, timestamp):
        date = time.strftime("%Y-%m-%d", time.gmtime(timestamp))
        canonical_headers = "content-type:application/json; charset=utf-8\nhost:{host}\nx-tc-action:{action}\n".format(
            host=self.host, action=action.lower())
        signed_headers = "content-type;host;x-tc-action"
        hashed_payload = hashlib.sha256(_bytes(payload)).hexdigest()
        canonical_request = "POST\n/\n\n{headers}\n{signed}\n{hashed}".format(
            headers=canonical_headers, signed=signed_headers, hashed=hashed_payload)
        scope = "{date}/{service}/tc3_request".format(date=date, service=self.service)
        string_to_sign = "TC3-HMAC-SHA256\n{ts}\n{scope}\n{hashed}".format(
            ts=timestamp, scope=scope,
            hashed=hashlib.sha256(_bytes(canonical_request)).hexdigest())
        secret_date = hmac.new(_bytes("TC3" + self.secret_key), _bytes(date), hashlib.sha256).digest()
        secret_service = hmac.new(secret_date, _bytes(self.service), hashlib.sha256).digest()
        secret_signing = hmac.new(secret_service, _bytes("tc3_request"), hashlib.sha256).digest()
        signature = hmac.new(secret_signing, _bytes(string_to_sign), hashlib.sha256).hexdigest()
        return "TC3-HMAC-SHA256 Credential={sid}/{scope}, SignedHeaders={signed}, Signature={sig}".format(
            sid=self.secret_id, scope=scope, signed=signed_headers, sig=signature)

    def send_request(self, action, params):
        if requests is None:
            return None, u"缺少 requests"
        payload = _dump(params)
        timestamp = int(time.time())
        headers = {
            "Authorization": self._sign(action, payload, timestamp),
            "Content-Type": "application/json; charset=utf-8",
            "Host": self.host,
            "X-TC-Action": action,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Version": self.version,
        }
        url = "https://" + self.host
        try:
            response = requests.post(url, data=payload, headers=headers, timeout=10)
        except Exception as exc:
            return _http_error(url, exc)
        try:
            body = json.loads(response.content)
        except ValueError:
            return None, u"返回结果非json，原始数据为:{body}".format(body=_show(response.content))
        if not isinstance(body, dict):
            return None, u"返回结果不是json对象"
        result = body.get("Response") or {}
        if not isinstance(result, dict):
            return None, u"返回结果不是json对象"
        error = result.get("Error")
        if error:
            if not isinstance(error, dict):
                return None, _show(error) or u"请求失败"
            message = _text(error.get("Message") or error.get("Code") or u"请求失败")
            code = _text(error.get("Code") or "")
            # 只有拉列表会在域名没有记录时返回这个错误。别的接口遇到同一错误码仍是失败。
            if action == "DescribeRecordList" and "NoDataOfRecord" in code:
                return {"RecordList": [], "RecordCountInfo": {"TotalCount": 0}}, None
            return None, message
        return result, None

    def get_default_line_id(self):
        return "0"

    def append_rs(self, from_rs, to_rs):
        if not isinstance(from_rs, list):
            return
        for record in from_rs:
            if not isinstance(record, dict):
                continue
            raw_id = record.get("RecordId")
            if raw_id is None:
                raw_id = record.get("id")
            if raw_id is None:
                continue
            record_id = str(raw_id)
            record_type = record.get("Type") or record.get("type")
            to_rs[record_id] = {
                "sub_domain": record.get("Name") or record.get("name") or "@",
                "type": record_type,
                "line_id": str(record.get("LineId") or record.get("line_id") or "0"),
                "ip": _record_value(record_type, record.get("Value") or record.get("value")),
            }

    def get_all_record(self, domain):
        page_size = 3000
        offset = 0
        records = {}
        total = None
        while True:
            body, err = self.send_request("DescribeRecordList", {
                "Domain": domain, "Offset": offset, "Limit": page_size, "ErrorOnEmpty": "no"})
            if err:
                return None, err
            if "RecordCountInfo" not in body and "RecordList" not in body:
                return None, u"返回结果缺少记录列表"
            listed = body.get("RecordList") or []
            if not isinstance(listed, list):
                return None, u"返回结果缺少记录列表"
            if total is None:
                info = body.get("RecordCountInfo") or {}
                try:
                    total = int(info.get("TotalCount"))
                except (TypeError, ValueError):
                    total = len(listed)
                if total < len(listed):
                    total = len(listed)
            if not listed:
                if total and offset < total:
                    return None, u"返回结果缺少记录列表"
                break
            before = len(records)
            self.append_rs(listed, records)
            if len(records) == before:
                return None, u"返回结果缺少记录列表"
            offset += len(listed)
            if offset >= total:
                break
            if offset > 100000:
                return None, u"记录过多，已停止"
        return records, None

    def get_record(self, domain, record_id):
        record_id, err = _as_int(record_id)
        if err:
            return None, err
        body, err = self.send_request("DescribeRecord", {"Domain": domain, "RecordId": record_id})
        if err:
            return None, err
        record = body.get("RecordInfo") or {}
        if not isinstance(record, dict):
            return None, u"返回结果缺少记录"
        record_type = record.get("RecordType")
        return {
            "sub_domain": record.get("SubDomain"),
            "domain": domain,
            "line": str(record.get("RecordLineId") or "0"),
            "type": record_type,
            "value": _record_value(record_type, record.get("Value")),
            "ttl": record.get("TTL"),
        }, None

    def get_lines(self, domain, zone_id):
        grade, err = self.get_domain_grade(domain)
        params = {"Domain": domain}
        if grade:
            params["DomainGrade"] = grade
        body, err = self.send_request("DescribeRecordLineList", params)
        if err and grade:
            body, err = self.send_request("DescribeRecordLineList", {"Domain": domain})
        if err:
            return None, err
        items = body.get("LineList") or []
        if not isinstance(items, list):
            return None, u"返回结果缺少线路"
        lines = []
        for item in items:
            if not isinstance(item, dict):
                continue
            if "Useful" in item and not item.get("Useful"):
                continue
            line_id = item.get("LineId")
            if line_id is None or line_id == "":
                continue
            lines.append({"id": str(line_id), "name": item.get("Name")})
        if not lines:
            lines.append({"id": self.get_default_line_id(), "name": self.default_line_name})
        return json.dumps(_plain(lines)), None

    def get_domain_grade(self, domain):
        body, err = self.send_request("DescribeDomain", {"Domain": domain})
        if err:
            return None, err
        info = body.get("DomainInfo") or {}
        if not isinstance(info, dict):
            return None, None
        return info.get("Grade"), None

    def _line_names(self, domain):
        cached = getattr(self, "_line_name_cache", None)
        if cached and cached[0] == domain:
            return cached[1]
        names = {}
        grade, _err = self.get_domain_grade(domain)
        params = {"Domain": domain}
        if grade:
            params["DomainGrade"] = grade
        body, err = self.send_request("DescribeRecordLineList", params)
        if err:
            body, err = self.send_request("DescribeRecordLineList", {"Domain": domain})
        if not err and isinstance(body, dict):
            for item in body.get("LineList") or []:
                if not isinstance(item, dict):
                    continue
                line_id = item.get("LineId")
                if line_id is None or line_id == "":
                    continue
                name = item.get("Name") or self.default_line_name
                names[str(line_id)] = name
        self._line_name_cache = (domain, names)
        return names

    def _line_name(self, domain, line_id):
        line_id = str(line_id or self.get_default_line_id())
        if line_id == str(self.get_default_line_id()):
            return self.default_line_name
        return self._line_names(domain).get(line_id) or self.default_line_name

    def _record_params(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        try:
            ttl_value = int(ttl or 600)
        except (TypeError, ValueError):
            return None, u"TTL不正确"
        if record_type == "CNAME":
            record_line_id = self.get_default_line_id()
        line_id = str(record_line_id or self.get_default_line_id())
        params = {
            "Domain": domain,
            "SubDomain": sub_domain or "@",
            "RecordType": record_type,
            "RecordLine": self._line_name(domain, line_id),
            "RecordLineId": line_id,
            "Value": ip,
            "TTL": ttl_value,
        }
        if record_type == "MX":
            params["MX"] = 10
        return params, None

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        params, err = self._record_params(domain, sub_domain, record_type, record_line_id, ip, ttl)
        if err:
            return None, err
        body, err = self.send_request("CreateRecord", params)
        if err:
            return None, err
        if body.get("RecordId") is None:
            return None, u"返回结果缺少记录编号"
        return str(body.get("RecordId")), None

    def del_record(self, domain, record_id):
        record_id, err = _as_int(record_id)
        if err:
            return None, err
        body, err = self.send_request("DeleteRecord", {"Domain": domain, "RecordId": record_id})
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl):
        params, err = self._record_params(domain, sub_domain, record_type, record_line_id, ip, ttl)
        if err:
            return None, err
        record_id, err = _as_int(record_id)
        if err:
            return None, err
        params["RecordId"] = record_id
        body, err = self.send_request("ModifyRecord", params)
        if err:
            return None, err
        return True, None
