# -*- coding: utf-8 -*-
import hashlib
import hmac
import json
import math
import sys
import time

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None


def _unicode():
    try:
        return unicode
    except NameError:
        return str


def _text(value):
    text = _unicode()
    if value is None:
        return text("")
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text(value)


def _bytes(value):
    text = _unicode()
    if isinstance(value, text):
        return value.encode("utf-8")
    if isinstance(value, bytes):
        return value
    return str(value).encode("utf-8")


class Dns(_dns_base):
    host = "dnspod.tencentcloudapi.com"
    service = "dnspod"
    version = "2021-03-23"

    def __init__(self, auth):
        try:
            auth = json.loads(auth)
        except ValueError:
            raise ValueError(u"传入的验证信息非json")
        secret_id = auth.get("id") or auth.get("secret_id")
        secret_key = auth.get("token") or auth.get("secret_key")
        if not secret_id:
            raise ValueError(u"auth中找不到id")
        if not secret_key:
            raise ValueError(u"auth中找不到token")
        self.secret_id = _text(secret_id)
        self.secret_key = _text(secret_key)

    def _sign(self, action, payload, timestamp):
        date = time.strftime("%Y-%m-%d", time.gmtime(timestamp))
        canonical_headers = "content-type:application/json; charset=utf-8\nhost:{host}\nx-tc-action:{action}\n".format(
            host=self.host, action=action.lower())
        signed_headers = "content-type;host;x-tc-action"
        hashed_payload = hashlib.sha256(_bytes(payload)).hexdigest()
        canonical_request = "POST\n/\n\n{headers}\n{signed}\n{hashed}".format(
            headers=canonical_headers, signed=signed_headers, hashed=hashed_payload)
        scope = "{date}/{service}/tc3_request".format(date=date, service=self.service)
        string_to_sign = "TC3-HMAC-SHA256\n{ts}\n{scope}\n{hashed}".format(
            ts=timestamp, scope=scope,
            hashed=hashlib.sha256(_bytes(canonical_request)).hexdigest())
        secret_date = hmac.new(_bytes("TC3" + self.secret_key), _bytes(date), hashlib.sha256).digest()
        secret_service = hmac.new(secret_date, _bytes(self.service), hashlib.sha256).digest()
        secret_signing = hmac.new(secret_service, _bytes("tc3_request"), hashlib.sha256).digest()
        signature = hmac.new(secret_signing, _bytes(string_to_sign), hashlib.sha256).hexdigest()
        return "TC3-HMAC-SHA256 Credential={sid}/{scope}, SignedHeaders={signed}, Signature={sig}".format(
            sid=self.secret_id, scope=scope, signed=signed_headers, sig=signature)

    def send_request(self, action, params):
        if requests is None:
            return None, u"缺少 requests"
        payload = _bytes(json.dumps(params, ensure_ascii=False, separators=(",", ":")))
        timestamp = int(time.time())
        headers = {
            "Authorization": self._sign(action, payload, timestamp),
            "Content-Type": "application/json; charset=utf-8",
            "Host": self.host,
            "X-TC-Action": action,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Version": self.version,
        }
        url = "https://" + self.host
        try:
            response = requests.post(url, data=payload, headers=headers, timeout=10)
            try:
                body = json.loads(response.content)
            except ValueError:
                return None, u"返回结果非json，原始数据为:{body}".format(body=response.content)
            result = body.get("Response") or {}
            error = result.get("Error")
            if error:
                message = error.get("Message") or error.get("Code") or u"请求失败"
                code = error.get("Code") or ""
                if "NoDataOfRecord" in code or message == u"记录列表为空":
                    return {"RecordList": [], "RecordCountInfo": {"TotalCount": 0}}, None
                return None, message
            return result, None
        except requests.ConnectTimeout:
            return None, u"url:{url} 连接超时".format(url=url)
        except requests.ConnectionError:
            return None, u"url:{url} 连接错误".format(url=url)
        except requests.Timeout:
            return None, u"url:{url} 读取超时".format(url=url)

    def get_default_line_id(self):
        return "0"

    def append_rs(self, from_rs, to_rs):
        for record in from_rs or []:
            record_id = str(record.get("RecordId") or record.get("id"))
            to_rs[record_id] = {
                "sub_domain": record.get("Name") or record.get("name") or "@",
                "type": record.get("Type") or record.get("type"),
                "line_id": str(record.get("LineId") or record.get("line_id") or "0"),
                "ip": record.get("Value") or record.get("value"),
            }

    def get_all_record(self, domain):
        page_size = 3000
        offset = 0
        body, err = self.send_request("DescribeRecordList", {"Domain": domain, "Offset": offset, "Limit": page_size})
        if err:
            return None, err
        total = int(((body.get("RecordCountInfo") or {}).get("TotalCount")) or 0)
        if total == 0:
            return {}, None
        records = {}
        self.append_rs(body.get("RecordList"), records)
        total_page = int(math.ceil(total / float(page_size)))
        for _ in range(total_page - 1):
            offset += page_size
            body, err = self.send_request("DescribeRecordList", {"Domain": domain, "Offset": offset, "Limit": page_size})
            if err:
                return None, err
            self.append_rs(body.get("RecordList"), records)
        return records, None

    def get_record(self, domain, record_id):
        body, err = self.send_request("DescribeRecord", {"Domain": domain, "RecordId": int(record_id)})
        if err:
            return None, err
        record = body.get("RecordInfo") or {}
        return {
            "sub_domain": record.get("SubDomain"),
            "domain": domain,
            "line": str(record.get("RecordLineId") or "0"),
            "type": record.get("RecordType"),
            "value": record.get("Value"),
            "ttl": record.get("TTL"),
        }, None

    def get_lines(self, domain, zone_id):
        grade, err = self.get_domain_grade(domain)
        params = {"Domain": domain}
        if grade:
            params["DomainGrade"] = grade
        body, err = self.send_request("DescribeRecordLineList", params)
        if err:
            return None, err
        lines = []
        for item in body.get("LineList") or []:
            lines.append({"id": str(item.get("LineId")), "name": item.get("Name")})
        if not lines:
            lines.append({"id": "0", "name": u"默认"})
        return json.dumps(lines, ensure_ascii=False), None

    def get_domain_grade(self, domain):
        body, err = self.send_request("DescribeDomain", {"Domain": domain})
        if err:
            return None, err
        info = body.get("DomainInfo") or {}
        return info.get("Grade"), None

    def _record_params(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        if record_type == "CNAME":
            record_line_id = self.get_default_line_id()
        params = {
            "Domain": domain,
            "SubDomain": sub_domain or "@",
            "RecordType": record_type,
            "RecordLine": u"默认",
            "RecordLineId": str(record_line_id or "0"),
            "Value": ip,
            "TTL": int(ttl or 600),
        }
        if record_type == "MX":
            params["MX"] = 10
        return params

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        body, err = self.send_request("CreateRecord", self._record_params(domain, sub_domain, record_type, record_line_id, ip, ttl))
        if err:
            return None, err
        return str(body.get("RecordId")), None

    def del_record(self, domain, record_id):
        body, err = self.send_request("DeleteRecord", {"Domain": domain, "RecordId": int(record_id)})
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl):
        params = self._record_params(domain, sub_domain, record_type, record_line_id, ip, ttl)
        params["RecordId"] = int(record_id)
        body, err = self.send_request("ModifyRecord", params)
        if err:
            return None, err
        return True, None
