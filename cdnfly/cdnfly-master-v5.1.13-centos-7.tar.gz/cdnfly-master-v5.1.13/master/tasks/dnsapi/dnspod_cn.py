# -*- coding: utf-8 -*-
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.append(_here)
import tencent_dns


class Dns(tencent_dns.Dns):
    host = "dnspod.tencentcloudapi.com"
    default_line_name = u"默认"
