# -*- coding: utf-8 -*-
import json
import os
import sys

sys.path.append("/opt/cdnfly/master/")

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None


def _unicode():
    try:
        return unicode
    except NameError:
        return str


def _text(value):
    text = _unicode()
    if value is None:
        return text("")
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text(value)


class Dns(_dns_base):
    zone_cache = "/opt/cloudflare_zone_id"

    def __init__(self, auth):
        try:
            auth = json.loads(auth)
        except ValueError:
            raise ValueError(u"传入的验证信息非json")
        email = _text(auth.get("email") or auth.get("id") or "")
        key = _text(auth.get("key") or auth.get("token") or "")
        if "@" in email and key:
            self.mode = "legacy"
            self.email = email
            self.key = key
        else:
            token = key or email
            if not token:
                raise ValueError(u"auth中找不到key")
            self.mode = "token"
            self.token = token
        self.zone_hint = _text(auth.get("zone_id") or "")

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.mode == "legacy":
            headers["X-Auth-Email"] = self.email
            headers["X-Auth-Key"] = self.key
        else:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def request(self, method, url, data=None):
        if requests is None:
            return None, u"缺少 requests"
        req = getattr(requests, method, None)
        try:
            payload = None
            if data is not None:
                payload = json.dumps(data)
            response = req(url, data=payload, headers=self._headers(), timeout=10)
            try:
                body = json.loads(response.content)
            except ValueError:
                return None, u"返回结果非json，原始数据为:{body}".format(body=response.content)
            if not body.get("success"):
                errors = body.get("errors") or []
                message = errors[0].get("message") if errors else u"请求失败"
                return None, message
            return body, None
        except requests.ConnectTimeout:
            return None, u"url:{url} 连接超时".format(url=url)
        except requests.ConnectionError:
            return None, u"url:{url} 连接错误".format(url=url)
        except requests.Timeout:
            return None, u"url:{url} 读取超时".format(url=url)

    def get_default_line_id(self):
        return "0"

    def _load_cache(self):
        if not os.path.exists(self.zone_cache):
            return {}
        try:
            with open(self.zone_cache) as handle:
                data = json.loads(handle.read())
            if isinstance(data, dict):
                return data
        except (ValueError, IOError, OSError):
            return {}
        return {}

    def _save_cache(self, data):
        try:
            with open(self.zone_cache, "w") as handle:
                handle.write(json.dumps(data))
        except (IOError, OSError):
            return

    def get_zone_id(self, domain):
        if self.zone_hint:
            return self.zone_hint, None
        cache = self._load_cache()
        if cache.get(domain):
            return cache[domain], None
        page = 1
        while True:
            url = "https://api.cloudflare.com/client/v4/zones?page={page}&per_page=50&name={name}".format(page=page, name=domain)
            body, err = self.request("get", url)
            if err:
                return None, err
            for zone in body.get("result") or []:
                if zone.get("name") == domain:
                    cache[domain] = zone.get("id")
                    self._save_cache(cache)
                    return zone.get("id"), None
            info = body.get("result_info") or {}
            if page >= int(info.get("total_pages") or 1):
                break
            page += 1
        return None, u"找不到此域名"

    def _sub_domain(self, name, domain):
        name = name or ""
        if name == domain or name == domain + ".":
            return "@"
        suffix = "." + domain
        if name.endswith(suffix):
            return name[:-len(suffix)]
        return name

    def append_rs(self, from_rs, to_rs, domain):
        for record in from_rs or []:
            record_id = str(record.get("id"))
            to_rs[record_id] = {
                "sub_domain": self._sub_domain(record.get("name"), domain),
                "type": record.get("type"),
                "line_id": "0",
                "ip": record.get("content"),
            }

    def get_all_record(self, domain):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        page = 1
        page_size = 100
        records = {}
        while True:
            url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records?page={page}&per_page={size}".format(
                zone_id=zone_id, page=page, size=page_size)
            body, err = self.request("get", url)
            if err:
                return None, err
            self.append_rs(body.get("result"), records, domain)
            info = body.get("result_info") or {}
            total_pages = int(info.get("total_pages") or 1)
            if page >= total_pages:
                break
            page += 1
        return records, None

    def get_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=zone_id, record_id=record_id)
        body, err = self.request("get", url)
        if err:
            return None, err
        record = body.get("result") or {}
        return {
            "sub_domain": self._sub_domain(record.get("name"), domain),
            "domain": domain,
            "line": "0",
            "type": record.get("type"),
            "value": record.get("content"),
            "ttl": record.get("ttl"),
        }, None

    def get_lines(self, domain, zone_id):
        return json.dumps([{"id": "0", "name": u"默认"}]), None

    def _fqdn(self, sub_domain, domain):
        if not sub_domain or sub_domain == "@":
            return domain
        return sub_domain + "." + domain

    def _payload(self, domain, sub_domain, record_type, ip, ttl):
        return {
            "type": record_type,
            "name": self._fqdn(sub_domain, domain),
            "content": ip,
            "ttl": int(ttl or 600),
            "proxied": False,
        }

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records".format(zone_id=zone_id)
        body, err = self.request("post", url, self._payload(domain, sub_domain, record_type, ip, ttl))
        if err:
            return None, err
        return str((body.get("result") or {}).get("id")), None

    def del_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=zone_id, record_id=record_id)
        body, err = self.request("delete", url)
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=zone_id, record_id=record_id)
        body, err = self.request("put", url, self._payload(domain, sub_domain, record_type, ip, ttl))
        if err:
            return None, err
        return True, None
