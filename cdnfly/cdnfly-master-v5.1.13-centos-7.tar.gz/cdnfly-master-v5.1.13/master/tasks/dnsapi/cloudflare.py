# -*- coding: utf-8 -*-
import json
import os
import sys

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

sys.path.append("/opt/cdnfly/master/")

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None


def _unicode():
    try:
        return unicode
    except NameError:
        return str


def _text(value):
    text = _unicode()
    if value is None:
        return text("")
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text(value)


def _http_error(url, exc):
    name = exc.__class__.__name__
    if name in ("ConnectTimeout", "ConnectTimeoutError"):
        return None, u"url:{url} 连接超时".format(url=url)
    if name in ("Timeout", "ReadTimeout"):
        return None, u"url:{url} 读取超时".format(url=url)
    if name in ("ConnectionError", "ProtocolError"):
        return None, u"url:{url} 连接错误".format(url=url)
    return None, u"url:{url} {err}".format(url=url, err=exc)


class Dns(_dns_base):
    zone_cache = "/opt/cloudflare_zone_id"

    def __init__(self, auth):
        try:
            auth = json.loads(auth)
        except ValueError:
            raise ValueError(u"传入的验证信息非json")
        email = _text(auth.get("email") or auth.get("id") or "").strip()
        key = _text(auth.get("key") or auth.get("token") or "").strip()
        if "@" in email and key:
            self.mode = "legacy"
            self.email = email
            self.key = key
        elif email and "@" not in email:
            self.mode = "token"
            self.token = email
        elif key:
            self.mode = "token"
            self.token = key
        else:
            raise ValueError(u"auth中找不到key")
        self.zone_hint = _text(auth.get("zone_id") or "").strip()

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.mode == "legacy":
            headers["X-Auth-Email"] = self.email
            headers["X-Auth-Key"] = self.key
        else:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def request(self, method, url, data=None):
        if requests is None:
            return None, u"缺少 requests"
        req = getattr(requests, method, None)
        try:
            payload = None
            if data is not None:
                payload = json.dumps(data)
            response = req(url, data=payload, headers=self._headers(), timeout=10)
        except Exception as exc:
            return _http_error(url, exc)
        try:
            body = json.loads(response.content)
        except ValueError:
            return None, u"返回结果非json，原始数据为:{body}".format(body=response.content)
        if not body.get("success"):
            errors = body.get("errors") or []
            message = errors[0].get("message") if errors else u"请求失败"
            return None, message
        return body, None

    def get_default_line_id(self):
        return "0"

    def _load_cache(self):
        if not os.path.exists(self.zone_cache):
            return {}
        try:
            with open(self.zone_cache) as handle:
                data = json.loads(handle.read())
            if isinstance(data, dict):
                return data
        except (ValueError, IOError, OSError):
            return {}
        return {}

    def _save_cache(self, data):
        try:
            with open(self.zone_cache, "w") as handle:
                handle.write(json.dumps(data))
        except (IOError, OSError):
            return

    def _confirm_zone(self, zone_id, domain):
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}".format(zone_id=quote(str(zone_id)))
        body, err = self.request("get", url)
        if err:
            return None, err
        zone = body.get("result") or {}
        if _text(zone.get("name")).lower() != _text(domain).lower():
            return None, u"找不到此域名"
        return zone.get("id"), None

    def get_zone_id(self, domain):
        if self.zone_hint:
            zone_id, err = self._confirm_zone(self.zone_hint, domain)
            if err:
                return None, err
            cache = self._load_cache()
            cache[domain] = zone_id
            self._save_cache(cache)
            return zone_id, None
        cache = self._load_cache()
        cached = cache.get(domain)
        if cached:
            zone_id, err = self._confirm_zone(cached, domain)
            if not err:
                return zone_id, None
        page = 1
        while page <= 100:
            url = "https://api.cloudflare.com/client/v4/zones?page={page}&per_page=50&name={name}".format(
                page=page, name=quote(str(domain)))
            body, err = self.request("get", url)
            if err:
                return None, err
            for zone in body.get("result") or []:
                if _text(zone.get("name")).lower() == _text(domain).lower():
                    cache[domain] = zone.get("id")
                    self._save_cache(cache)
                    return zone.get("id"), None
            info = body.get("result_info") or {}
            if page >= int(info.get("total_pages") or 1):
                break
            page += 1
        return None, u"找不到此域名"

    def _sub_domain(self, name, domain):
        name = name or ""
        if name == domain or name == domain + ".":
            return "@"
        suffix = "." + domain
        if name.endswith(suffix):
            return name[:-len(suffix)]
        return name

    def append_rs(self, from_rs, to_rs):
        domain = getattr(self, "domain_name", "")
        for record in from_rs or []:
            if not record.get("id"):
                continue
            record_id = str(record.get("id"))
            to_rs[record_id] = {
                "sub_domain": self._sub_domain(record.get("name"), domain),
                "type": record.get("type"),
                "line_id": "0",
                "ip": record.get("content"),
            }

    def get_all_record(self, domain):
        self.domain_name = domain
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        page = 1
        page_size = 100
        records = {}
        while page <= 100:
            url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records?page={page}&per_page={size}".format(
                zone_id=quote(str(zone_id)), page=page, size=page_size)
            body, err = self.request("get", url)
            if err:
                return None, err
            self.append_rs(body.get("result"), records)
            info = body.get("result_info") or {}
            total_pages = int(info.get("total_pages") or 1)
            if page >= total_pages:
                break
            page += 1
        return records, None

    def get_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=quote(str(zone_id)), record_id=quote(str(record_id)))
        body, err = self.request("get", url)
        if err:
            return None, err
        record = body.get("result") or {}
        return {
            "sub_domain": self._sub_domain(record.get("name"), domain),
            "domain": domain,
            "line": "0",
            "type": record.get("type"),
            "value": record.get("content"),
            "ttl": record.get("ttl"),
        }, None

    def get_lines(self, domain, zone_id):
        if zone_id:
            self.zone_hint = _text(zone_id).strip()
        found, err = self.get_zone_id(domain)
        if err:
            return None, err
        if not found:
            return None, u"找不到此域名"
        return json.dumps([{"id": "0", "name": u"默认"}]), None

    def _fqdn(self, sub_domain, domain):
        if not sub_domain or sub_domain == "@":
            return domain
        return sub_domain + "." + domain

    def _payload(self, domain, sub_domain, record_type, ip, ttl):
        try:
            ttl_value = int(ttl or 600)
        except (TypeError, ValueError):
            return None, u"TTL不正确"
        payload = {
            "type": record_type,
            "name": self._fqdn(sub_domain, domain),
            "content": ip,
            "ttl": ttl_value,
        }
        if record_type in ("A", "AAAA", "CNAME"):
            payload["proxied"] = False
        if record_type == "MX":
            payload["priority"] = 10
        return payload, None

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records".format(zone_id=quote(str(zone_id)))
        payload, err = self._payload(domain, sub_domain, record_type, ip, ttl)
        if err:
            return None, err
        body, err = self.request("post", url, payload)
        if err:
            return None, err
        if not (body.get("result") or {}).get("id"):
            return None, u"返回结果缺少记录编号"
        return str(body.get("result").get("id")), None

    def del_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=quote(str(zone_id)), record_id=quote(str(record_id)))
        body, err = self.request("delete", url)
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=quote(str(zone_id)), record_id=quote(str(record_id)))
        payload, err = self._payload(domain, sub_domain, record_type, ip, ttl)
        if err:
            return None, err
        body, err = self.request("put", url, payload)
        if err:
            return None, err
        return True, None
