# -*- coding: utf-8 -*-
import json
import os
import sys

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

sys.path.append("/opt/cdnfly/master/")

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None


def _unicode():
    try:
        return unicode
    except NameError:
        return str


def _text(value):
    text = _unicode()
    if value is None:
        return text("")
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return text(value)


def _show(value):
    try:
        return _text(value)
    except Exception:
        try:
            return _text(repr(value))
        except Exception:
            return u""


def _load_auth(auth):
    if isinstance(auth, dict):
        return auth
    try:
        loaded = json.loads(auth)
    except (ValueError, TypeError):
        raise ValueError(u"传入的验证信息非json")
    if not isinstance(loaded, dict):
        raise ValueError(u"传入的验证信息非json")
    return loaded


def _idna_text(value):
    text = _text(value).strip().strip(".")
    if not text:
        return text
    try:
        ascii_name = text.encode("ascii")
    except Exception:
        return text
    try:
        return _text(ascii_name.decode("idna"))
    except Exception:
        return text


def _punycode(value):
    text = _idna_text(value)
    try:
        encoded = text.encode("idna")
    except Exception:
        return text
    if isinstance(encoded, _unicode()):
        return encoded
    return encoded.decode("ascii")


def _fold_dots(value):
    # 中文输入法打出来的句号、全角点，DNS 里都只是普通的点。
    text = _text(value)
    for char in (u"。", u"．", u"｡"):
        text = text.replace(char, u".")
    return text


def _zone_key(value):
    # 大写的 XN-- 不能直接解码。先转成小写，例子.com 和 XN--FSQU00A.COM 才是同一个域名。
    return _idna_text(_fold_dots(_text(value).strip().lower()))


def _hostname_wire(value):
    # 接口把域名存成 punycode。中文目标直接提交时会写不进去。
    text = _fold_dots(value).strip().strip(".")
    if not text:
        return text
    return _punycode(text)


def _align_hostname(value, domain):
    # 读回来的目标是 punycode。记录同步用的是配置里的写法，后缀要拼回那个写法。
    if value is None:
        return value
    text = _text(value)
    if len(text) > 1 and text.endswith(u"."):
        text = text[:-1]
    norm_value = _zone_key(text)
    norm_domain = _zone_key(domain)
    if not norm_domain or not norm_value:
        return text
    domain_text = _text(domain)
    if norm_value == norm_domain:
        return domain_text
    suffix = u"." + norm_domain
    if not norm_value.endswith(suffix):
        return text
    raw = _idna_text(_fold_dots(text).strip().strip("."))
    raw_zone = _idna_text(_fold_dots(_text(domain).strip()).strip().strip("."))
    raw_suffix = u"." + raw_zone
    if raw.lower().endswith(raw_suffix.lower()) and len(raw) == len(norm_value):
        host = raw[:-len(raw_suffix)]
    else:
        host = norm_value[:-len(suffix)]
    if not host:
        return domain_text
    return host + u"." + domain_text


def _quote_raw(value):
    return quote(_text(value).encode("utf-8"))


def _quote_domain(value):
    return quote(_punycode(value).encode("utf-8"))


def _cf_error(body):
    errors = body.get("errors") or []
    if not errors:
        return u"请求失败"
    first = errors[0]
    if isinstance(first, dict):
        return _text(first.get("message") or first.get("code") or u"请求失败")
    shown = _show(first)
    return shown or u"请求失败"


def _plain(value):
    text = _unicode()
    if isinstance(value, dict):
        return dict((_plain(key), _plain(item)) for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, text):
        return value
    if isinstance(value, bytes):
        try:
            return _text(value)
        except Exception:
            return value.decode("latin-1")
    return value


def _record_value(record_type, value):
    if value is None or record_type not in ("CNAME", "NS", "MX", "SRV"):
        return value
    text = _text(value)
    if len(text) > 1 and text.endswith(u"."):
        return text[:-1]
    return value


def _ttl_text(value):
    if value is None or value == "":
        return value
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return _text(value)


def _http_error(url, exc):
    name = exc.__class__.__name__
    if name in ("ConnectTimeout", "ConnectTimeoutError"):
        return None, u"url:{url} 连接超时".format(url=url)
    if name in ("Timeout", "ReadTimeout"):
        return None, u"url:{url} 读取超时".format(url=url)
    if name in ("ConnectionError", "ProtocolError"):
        return None, u"url:{url} 连接错误".format(url=url)
    return None, u"url:{url} {err}".format(url=url, err=_show(exc))


class Dns(_dns_base):
    zone_cache = "/opt/cloudflare_zone_id"

    def __init__(self, auth):
        auth = _load_auth(auth)
        email = _text(auth.get("email") or auth.get("id") or "").strip()
        key = _text(auth.get("key") or auth.get("token") or "").strip()
        if "@" in email and key:
            self.mode = "legacy"
            self.email = email
            self.key = key
        elif email and "@" not in email:
            self.mode = "token"
            self.token = email
        elif key:
            self.mode = "token"
            self.token = key
        else:
            raise ValueError(u"auth中找不到key")
        self.zone_hint = _text(auth.get("zone_id") or "").strip()

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.mode == "legacy":
            headers["X-Auth-Email"] = self.email
            headers["X-Auth-Key"] = self.key
        else:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def request(self, method, url, data=None):
        if requests is None:
            return None, u"缺少 requests"
        req = getattr(requests, method, None)
        try:
            payload = None
            if data is not None:
                payload = json.dumps(_plain(data), separators=(",", ":"))
            response = req(url, data=payload, headers=self._headers(), timeout=10)
        except Exception as exc:
            return _http_error(url, exc)
        try:
            body = json.loads(response.content)
        except ValueError:
            return None, u"返回结果非json，原始数据为:{body}".format(body=_show(response.content))
        if not isinstance(body, dict):
            return None, u"返回结果不是json对象"
        if not body.get("success"):
            return None, _cf_error(body)
        return body, None

    def get_default_line_id(self):
        return "0"

    def _load_cache(self):
        if not os.path.exists(self.zone_cache):
            return {}
        try:
            with open(self.zone_cache) as handle:
                data = json.loads(handle.read())
            if isinstance(data, dict):
                return data
        except (ValueError, IOError, OSError):
            return {}
        return {}

    def _save_cache(self, data):
        try:
            with open(self.zone_cache, "w") as handle:
                handle.write(json.dumps(data))
        except (IOError, OSError):
            return

    def _confirm_zone(self, zone_id, domain):
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}".format(zone_id=_quote_raw(zone_id))
        body, err = self.request("get", url)
        if err:
            return None, err
        zone = body.get("result") or {}
        if not isinstance(zone, dict):
            return None, u"找不到此域名"
        if _zone_key(zone.get("name")) != _zone_key(domain):
            return None, u"找不到此域名"
        found = zone.get("id")
        if not found:
            return None, u"找不到此域名"
        return found, None

    def get_zone_id(self, domain):
        if self.zone_hint:
            zone_id, err = self._confirm_zone(self.zone_hint, domain)
            if err:
                return None, err
            cache = self._load_cache()
            cache[domain] = zone_id
            self._save_cache(cache)
            return zone_id, None
        cache = self._load_cache()
        cached = cache.get(domain)
        if cached:
            zone_id, err = self._confirm_zone(cached, domain)
            if not err:
                return zone_id, None
        page = 1
        while page <= 100:
            url = "https://api.cloudflare.com/client/v4/zones?page={page}&per_page=50&name={name}".format(
                page=page, name=_quote_domain(_zone_key(domain)))
            body, err = self.request("get", url)
            if err:
                return None, err
            listed = body.get("result") or []
            if not isinstance(listed, list):
                return None, u"找不到此域名"
            for zone in listed:
                if not isinstance(zone, dict):
                    continue
                if _zone_key(zone.get("name")) != _zone_key(domain):
                    continue
                zone_id = zone.get("id")
                if not zone_id:
                    continue
                cache[domain] = zone_id
                self._save_cache(cache)
                return zone_id, None
            info = body.get("result_info") or {}
            try:
                total_pages = int(info.get("total_pages") or 1)
            except (TypeError, ValueError):
                total_pages = 1
            if page >= total_pages:
                break
            page += 1
        return None, u"找不到此域名"

    def _sub_domain(self, name, domain):
        raw = _idna_text(name)
        norm_name = _zone_key(name)
        norm_domain = _zone_key(domain)
        if not norm_name or norm_name == norm_domain:
            return "@"
        suffix = "." + norm_domain
        if not norm_name.endswith(suffix):
            return raw
        raw_domain = _idna_text(domain)
        raw_suffix = "." + raw_domain
        # 英文主机名大小写不动。大写 punycode 解码后长度变了，只能用解码后的主机名。
        if raw.lower().endswith(raw_suffix.lower()) and len(raw) == len(norm_name):
            return raw[:-len(raw_suffix)]
        return norm_name[:-len(suffix)]

    def append_rs(self, from_rs, to_rs):
        if not isinstance(from_rs, list):
            return
        domain = getattr(self, "domain_name", "")
        for record in from_rs:
            if not isinstance(record, dict) or not record.get("id"):
                continue
            record_id = str(record.get("id"))
            record_type = record.get("type")
            content = record.get("content")
            if record_type in ("CNAME", "NS", "MX", "SRV"):
                content = _align_hostname(content, domain)
            else:
                content = _record_value(record_type, content)
            to_rs[record_id] = {
                "sub_domain": self._sub_domain(record.get("name"), domain),
                "type": record_type,
                "line_id": "0",
                "ip": content,
                "ttl": _ttl_text(record.get("ttl")),
            }

    def get_all_record(self, domain):
        self.domain_name = domain
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        page = 1
        page_size = 100
        records = {}
        while page <= 100:
            url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records?page={page}&per_page={size}".format(
                zone_id=_quote_raw(zone_id), page=page, size=page_size)
            body, err = self.request("get", url)
            if err:
                return None, err
            listed = body.get("result")
            if not isinstance(listed, list):
                return None, u"返回结果缺少记录列表"
            before = len(records)
            self.append_rs(listed, records)
            if listed and len(records) == before:
                return None, u"返回结果缺少记录列表"
            info = body.get("result_info") if isinstance(body.get("result_info"), dict) else {}
            reported = info.get("total_pages")
            try:
                total_pages = int(reported) if reported not in (None, "") else None
            except (TypeError, ValueError):
                total_pages = None
            if len(listed) < page_size:
                break
            if total_pages is not None and total_pages >= 1 and page >= total_pages:
                break
            if page >= 100:
                return None, u"记录过多，已停止"
            page += 1
        return records, None

    def get_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=_quote_raw(zone_id), record_id=_quote_raw(record_id))
        body, err = self.request("get", url)
        if err:
            return None, err
        record = body.get("result") or {}
        if not isinstance(record, dict):
            return None, u"返回结果缺少记录"
        record_type = record.get("type")
        content = record.get("content")
        if record_type in ("CNAME", "NS", "MX", "SRV"):
            content = _align_hostname(content, domain)
        else:
            content = _record_value(record_type, content)
        return {
            "sub_domain": self._sub_domain(record.get("name"), domain),
            "domain": domain,
            "line": "0",
            "type": record_type,
            "value": content,
            "ttl": _ttl_text(record.get("ttl")),
        }, None

    def get_lines(self, domain, zone_id=None):
        # 线路同步只传域名。带了 zone_id 时用它覆盖鉴权里的值。
        if zone_id:
            self.zone_hint = _text(zone_id).strip()
        found, err = self.get_zone_id(domain)
        if err:
            return None, err
        if not found:
            return None, u"找不到此域名"
        return json.dumps([{"id": "0", "name": u"默认"}]), None

    def _fqdn(self, sub_domain, domain):
        sub_domain = _fold_dots(sub_domain).strip().strip(".")
        zone = _zone_key(domain)
        if not sub_domain or sub_domain == "@":
            name = zone
        else:
            name = sub_domain + u"." + zone
        # 整段转成 punycode，避免主机是中文、主域名却是 xn-- 的混写。
        return _punycode(name)

    def _payload(self, domain, sub_domain, record_type, ip, ttl):
        try:
            ttl_value = int(ttl or 600)
        except (TypeError, ValueError):
            return None, u"TTL不正确"
        content = ip
        if record_type in ("CNAME", "NS", "MX", "SRV"):
            content = _hostname_wire(ip)
        payload = {
            "type": record_type,
            "name": self._fqdn(sub_domain, domain),
            "content": content,
            "ttl": ttl_value,
        }
        if record_type in ("A", "AAAA", "CNAME"):
            payload["proxied"] = False
        if record_type == "MX":
            payload["priority"] = 10
        return payload, None

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl, weight=None):
        # 线路同步会传入 weight。Cloudflare 的记录没有这一项，收下即可。
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records".format(zone_id=_quote_raw(zone_id))
        payload, err = self._payload(domain, sub_domain, record_type, ip, ttl)
        if err:
            return None, err
        body, err = self.request("post", url, payload)
        if err:
            return None, err
        if not (body.get("result") or {}).get("id"):
            return None, u"返回结果缺少记录编号"
        return str(body.get("result").get("id")), None

    def del_record(self, domain, record_id):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=_quote_raw(zone_id), record_id=_quote_raw(record_id))
        body, err = self.request("delete", url)
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl, weight=None):
        zone_id, err = self.get_zone_id(domain)
        if err:
            return None, err
        url = "https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}".format(
            zone_id=_quote_raw(zone_id), record_id=_quote_raw(record_id))
        payload, err = self._payload(domain, sub_domain, record_type, ip, ttl)
        if err:
            return None, err
        body, err = self.request("put", url, payload)
        if err:
            return None, err
        return True, None
