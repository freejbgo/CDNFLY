# -*- coding: utf-8 -*-
import hashlib
import json
import os
import sys
import time

sys.path.append("/opt/cdnfly/master/")

try:
    from tasks.interface import dns as _dns_base
except ImportError:
    class _dns_base(object):
        pass

try:
    import requests
except ImportError:
    requests = None

_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.append(_here)

import tencent_dns


_api_base = u"https://www.51dns.com/api/"
_lines_path = os.path.join(_here, "dnsdotcom_lines.json")
_line_tree_cache = None


def _line_tree():
    global _line_tree_cache
    if _line_tree_cache is not None:
        return _line_tree_cache
    try:
        with open(_lines_path, "rb") as handle:
            raw = handle.read()
    except IOError:
        raise ValueError(u"缺少线路数据文件")
    try:
        loaded = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise ValueError(u"线路数据不是合法json")
    if not isinstance(loaded, list):
        raise ValueError(u"线路数据格式不正确")
    _line_tree_cache = loaded
    return _line_tree_cache


def _record_id_from_payload(data):
    if isinstance(data, dict):
        raw = data.get("recordID")
        if raw is None:
            raw = data.get("RecordId")
        if raw is None:
            raw = data.get("id")
        if raw is not None:
            return str(raw)
    elif isinstance(data, list):
        for item in data:
            raw = _record_id_from_payload(item)
            if raw is not None:
                return raw
    return None


class Dns(_dns_base):
    api_base = _api_base
    page_size = 1000
    default_line_name = u"默认"

    def __init__(self, auth):
        auth = tencent_dns._load_auth(auth)
        api_key = tencent_dns._text(
            auth.get("id") or auth.get("apiKey") or auth.get("authid")
        ).strip()
        api_secret = tencent_dns._text(
            auth.get("token") or auth.get("apiSecret") or auth.get("authtoken")
        ).strip()
        if not api_key:
            raise ValueError(u"auth中找不到id")
        if not api_secret:
            raise ValueError(u"auth中找不到token")
        self.api_key = api_key
        self.api_secret = api_secret
        self._domain_id_cache = {}

    def _sign(self, params):
        pairs = []
        for key in sorted(params):
            if key == u"hash":
                continue
            value = params[key]
            if value is None:
                continue
            pairs.append(u"{0}={1}".format(tencent_dns._text(key), tencent_dns._text(value)))
        blob = u"&".join(pairs) + self.api_secret
        return hashlib.md5(blob.encode("utf-8")).hexdigest()

    def _auth_params(self, params):
        merged = {}
        if isinstance(params, dict):
            for key, value in params.items():
                if value is None or value == "":
                    continue
                merged[tencent_dns._text(key)] = tencent_dns._text(value)
        merged[u"apiKey"] = self.api_key
        merged[u"timestamp"] = str(int(time.time()))
        merged[u"hash"] = self._sign(merged)
        return merged

    def send_request(self, path, params):
        if requests is None:
            return None, u"缺少 requests"
        path = tencent_dns._text(path).lstrip(u"/")
        if not path.endswith(u"/"):
            path += u"/"
        url = self.api_base + path
        query = self._auth_params(params)
        try:
            response = requests.get(url, params=query, timeout=10)
        except Exception as exc:
            return tencent_dns._http_error(url, exc)
        try:
            body = json.loads(response.content)
        except ValueError:
            return None, u"返回结果非json，原始数据为:{body}".format(
                body=tencent_dns._show(response.content))
        if not isinstance(body, dict):
            return None, u"返回结果不是json对象"
        code = body.get("code")
        code_int = None
        code_given = code not in (None, "")
        if code_given:
            try:
                code_int = int(code)
            except (TypeError, ValueError):
                message = body.get("message")
                if message not in (None, ""):
                    return None, tencent_dns._text(message)
                return None, u"请求失败"
        if code_int is not None and code_int != 0:
            message = body.get("message")
            if message is None or message == "":
                return None, u"请求失败"
            return None, tencent_dns._text(message)
        if not code_given and code_int is None:
            message = body.get("message")
            if message not in (None, ""):
                return None, tencent_dns._text(message)
        data = body.get("data")
        if data is None and not code_given and (body.get("message") in (None, "")):
            return None, u"请求失败"
        return data, None

    def _domain_key(self, domain):
        return tencent_dns._zone_name(domain)

    def _domain_id(self, domain):
        key = self._domain_key(domain)
        if key in self._domain_id_cache:
            return self._domain_id_cache[key], None
        data, err = self.send_request(u"domain/getsingle", {u"domainID": key})
        if err:
            return None, err
        domain_id = None
        if isinstance(data, dict):
            domain_id = data.get("domainID")
        if domain_id is None:
            return None, u"找不到此域名"
        domain_id = str(domain_id)
        self._domain_id_cache[key] = domain_id
        return domain_id, None

    def get_default_line_id(self):
        return u"0"

    def _sub_domain(self, host, domain):
        if host in (None, ""):
            return u"@"
        raw = tencent_dns._idna_text(tencent_dns._fold_dots(host).strip().strip("."))
        norm_host = tencent_dns._name_key(host)
        norm_domain = tencent_dns._name_key(domain)
        if not norm_host or not norm_domain or norm_host == norm_domain:
            return u"@"
        suffix = u"." + norm_domain
        if not norm_host.endswith(suffix):
            return raw or u"@"
        raw_domain = tencent_dns._idna_text(domain)
        raw_suffix = u"." + raw_domain
        if raw.lower().endswith(raw_suffix.lower()) and len(raw) == len(norm_host):
            label = raw[:-len(raw_suffix)]
        else:
            label = norm_host[:-len(suffix)]
        return label if label else u"@"

    def append_rs(self, from_rs, to_rs):
        if not isinstance(from_rs, list):
            return
        domain = getattr(self, "domain_name", u"")
        for record in from_rs:
            if not isinstance(record, dict):
                continue
            raw_id = record.get("recordID")
            if raw_id is None:
                raw_id = record.get("RecordId")
            if raw_id is None:
                raw_id = record.get("id")
            if raw_id is None:
                continue
            record_id = str(raw_id)
            record_type = tencent_dns._rtype(record.get("type") or record.get("Type"))
            line_id = record.get("viewID")
            if line_id is None or line_id == "":
                line_id = record.get("line_id")
            if line_id is None or line_id == "":
                line_id = self.get_default_line_id()
            host = record.get("record")
            if host is None or host == "":
                host = record.get("Name")
            if host is None or host == "":
                host = record.get("name")
            sub_domain = self._sub_domain(host, domain)
            ip = record.get("value")
            if ip is None:
                ip = record.get("Value")
            if record_type in ("CNAME", "NS", "MX", "SRV"):
                ip = tencent_dns._align_hostname(ip, domain)
            else:
                ip = tencent_dns._record_value(record_type, ip)
            ttl = record.get("TTL")
            if ttl is None:
                ttl = record.get("ttl")
            to_rs[record_id] = {
                "sub_domain": sub_domain,
                "type": record_type,
                "line_id": str(line_id),
                "ip": ip,
                "ttl": tencent_dns._ttl_text(ttl),
            }

    def get_all_record(self, domain):
        self.domain_name = domain
        domain_id, err = self._domain_id(domain)
        if err:
            return None, err
        page = 1
        records = {}
        total_page = None
        record_total = None
        last_listed = 0
        while True:
            data, err = self.send_request(u"record/list", {
                u"domainID": domain_id,
                u"page": str(page),
                u"pageSize": str(self.page_size),
            })
            if err:
                return None, err
            listed = []
            if isinstance(data, dict):
                if total_page is None:
                    raw_total = data.get("pageCount")
                    if raw_total in (None, ""):
                        raw_total = data.get("total_page")
                    try:
                        total_page = int(raw_total) if raw_total not in (None, "") else None
                    except (TypeError, ValueError):
                        total_page = None
                if record_total is None:
                    raw_count = data.get("recordCount")
                    try:
                        record_total = int(raw_count) if raw_count not in (None, "") else None
                    except (TypeError, ValueError):
                        record_total = None
                listed = data.get("data") or []
            elif isinstance(data, list):
                listed = data
            if not isinstance(listed, list):
                return None, u"返回结果缺少记录列表"
            if not listed:
                if page == 1 and record_total and record_total > 0:
                    return None, u"返回结果缺少记录列表"
                break
            before = len(records)
            self.append_rs(listed, records)
            if len(records) == before and listed:
                return None, u"返回结果缺少记录列表"
            last_listed = len(listed)
            if record_total is not None and len(records) >= record_total:
                break
            more = True
            if total_page is not None and page >= total_page and record_total is None:
                more = False
            elif last_listed < self.page_size:
                if total_page is not None and page < total_page:
                    more = True
                elif record_total is not None and len(records) < record_total:
                    more = True
                else:
                    more = False
            if not more:
                break
            page += 1
            if page > 10000:
                return None, u"记录过多，已停止"
        if record_total is not None and len(records) < record_total and last_listed >= self.page_size:
            return None, u"返回结果缺少记录列表"
        return records, None

    def get_record(self, domain, record_id):
        record_id, err = tencent_dns._as_int(record_id)
        if err:
            return None, err
        domain_id, err = self._domain_id(domain)
        if err:
            return None, err
        data, err = self.send_request(u"record/getsingle", {
            u"domainID": domain_id,
            u"recordID": str(record_id),
        })
        if err:
            return None, err
        if not isinstance(data, dict):
            return None, u"返回结果缺少记录"
        record_type = tencent_dns._rtype(data.get("type"))
        value = data.get("value")
        if record_type in ("CNAME", "NS", "MX", "SRV"):
            value = tencent_dns._align_hostname(value, domain)
        else:
            value = tencent_dns._record_value(record_type, value)
        sub_domain = self._sub_domain(data.get("record"), domain)
        return {
            "sub_domain": sub_domain,
            "domain": domain,
            "line": str(data.get("viewID") or self.get_default_line_id()),
            "type": record_type,
            "value": value,
            "ttl": tencent_dns._ttl_text(data.get("TTL")),
        }, None

    def get_lines(self, domain, zone_id=None):
        try:
            tree = _line_tree()
        except ValueError as exc:
            return None, tencent_dns._text(exc)
        return json.dumps(tencent_dns._plain(tree)), None

    def _build_create(self, domain, domain_id, sub_domain, record_type, record_line_id, ip, ttl, weight=None):
        try:
            ttl_value = int(ttl or 600)
        except (TypeError, ValueError):
            return None, u"TTL不正确"
        weight_value, err = tencent_dns._optional_weight(weight)
        if err:
            return None, err
        record_type = tencent_dns._rtype(record_type)
        value = ip
        if record_type in ("CNAME", "NS", "MX", "SRV"):
            value = tencent_dns._fold_dots(ip).strip().strip(".")
        params = {
            u"domainID": domain_id,
            u"host": self._sub_domain(sub_domain, domain),
            u"type": record_type,
            u"viewID": str(record_line_id or self.get_default_line_id()),
            u"value": value,
            u"TTL": str(ttl_value),
        }
        if record_type == u"MX":
            params[u"mx"] = u"10"
        elif weight_value is not None:
            params[u"mx"] = str(weight_value)
        return params, None

    def add_record(self, domain, sub_domain, record_type, record_line_id, ip, ttl, weight=None):
        domain_id, err = self._domain_id(domain)
        if err:
            return None, err
        params, err = self._build_create(domain, domain_id, sub_domain, record_type, record_line_id, ip, ttl, weight)
        if err:
            return None, err
        data, err = self.send_request(u"record/create", params)
        if err:
            return None, err
        record_id = _record_id_from_payload(data)
        if record_id is None:
            return None, u"返回结果缺少记录编号"
        return record_id, None

    def del_record(self, domain, record_id):
        record_id, err = tencent_dns._as_int(record_id)
        if err:
            return None, err
        domain_id, err = self._domain_id(domain)
        if err:
            return None, err
        _, err = self.send_request(u"record/remove", {
            u"domainID": domain_id,
            u"recordID": str(record_id),
        })
        if err:
            return None, err
        return True, None

    def update_record(self, domain, record_id, sub_domain, record_type, record_line_id, ip, ttl, weight=None):
        record_id, err = tencent_dns._as_int(record_id)
        if err:
            return None, err
        domain_id, err = self._domain_id(domain)
        if err:
            return None, err
        try:
            ttl_value = int(ttl or 600)
        except (TypeError, ValueError):
            return None, u"TTL不正确"
        weight_value, err = tencent_dns._optional_weight(weight)
        if err:
            return None, err
        record_type = tencent_dns._rtype(record_type)
        value = ip
        if record_type in ("CNAME", "NS", "MX", "SRV"):
            value = tencent_dns._fold_dots(ip).strip().strip(".")
        params = {
            u"domainID": domain_id,
            u"recordID": str(record_id),
            u"newhost": self._sub_domain(sub_domain, domain),
            u"newtype": record_type,
            u"newvalue": value,
            u"newttl": str(ttl_value),
            u"newviewID": str(record_line_id or self.get_default_line_id()),
        }
        if record_type == u"MX":
            params[u"newmx"] = u"10"
        elif weight_value is not None:
            params[u"newmx"] = str(weight_value)
        _, err = self.send_request(u"record/modify", params)
        if err:
            return None, err
        return True, None