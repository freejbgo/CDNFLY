# -*- coding: utf-8 -*-
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tencent_dns


class Dns(tencent_dns.Dns):
    host = "dnspod.intl.tencentcloudapi.com"
