/**

 @Name：layuiAdmin Echarts集成
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2
    
 */


layui.define(function(exports){
  // 获取域名列表
  var admin = layui.admin
  var $ = layui.$

  //区块轮播切换
  layui.use(['admin', 'carousel'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,carousel = layui.carousel
    ,element = layui.element
    ,device = layui.device();

    //轮播切换
    $('.layadmin-carousel').each(function(){
      var othis = $(this);
      carousel.render({
        elem: this
        ,width: '100%'
        ,arrow: 'none'
        ,interval: othis.data('interval')
        ,autoplay: othis.data('autoplay') === true
        ,trigger: (device.ios || device.android) ? 'click' : 'hover'
        ,anim: othis.data('anim')
      });
    });

  });


  //折线图
  layui.use(['admin', 'echarts','laydate', 'veikorI18n'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,laydate = layui.laydate
    ,element = layui.element
    ,echarts = layui.echarts
    ,veikorI18n = layui.veikorI18n;

    var siteRealtimeSeq = (window.__veikorSiteRealtimeSeq = (window.__veikorSiteRealtimeSeq || 0) + 1);

    function siteMonitorRoot() {
      var $body = $('#LAY_app_body');
      var $tab = $body.find('[lay-filter="monitor-tab"]').first();
      if ($tab.length) return $tab.closest('#component-tabs');
      return $body.find('#component-tabs').first();
    }
    function $sm(sel) {
      return siteMonitorRoot().find(sel);
    }

    function siteRealtimeStill() {
      if (siteRealtimeSeq !== window.__veikorSiteRealtimeSeq) return false;
      var path = [];
      try { path = layui.router().path || []; } catch (e) { return false; }
      if (path[0] !== 'site' || path[1] !== 'monitor' || path[2] !== 'realtime') return false;
      var body = document.querySelector('#LAY_app_body');
      return !!(body && body.querySelector('#bandwidth'));
    }

    function formatDate(time,format='YY-MM-DD hh:mm:ss'){
        var date = new Date(time);
     
        var year = date.getFullYear(),
            month = date.getMonth()+1,//月份是从0开始的
            day = date.getDate(),
            hour = date.getHours(),
            min = date.getMinutes(),
            sec = date.getSeconds();
        var preArr = Array.apply(null,Array(10)).map(function(elem, index) {
            return '0'+index;
        });//开个长度为10的数组 格式为 ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09"]
     
        var newTime = format.replace(/YY/g,year)
            .replace(/MM/g,preArr[month]||month)
            .replace(/DD/g,preArr[day]||day)
            .replace(/hh/g,preArr[hour]||hour)
            .replace(/mm/g,preArr[min]||min)
            .replace(/ss/g,preArr[sec]||sec);
     
        return newTime;
    };

    function render_date() {
      var el = $sm('#site-monitor-date')[0];
      if (!el || !siteRealtimeStill()) return;
      laydate.render({
        elem: el
        ,type: 'datetime'
        ,range: true
        ,format: 'yyyy-MM-dd (HH:mm)'
        ,value: formatDate(new Date().getTime() - 3600000, 'YY-MM-DD (hh:mm)') + " - " + formatDate(new Date().getTime(), 'YY-MM-DD (hh:mm)')
        ,done: function(value, date, endDate){
          if (!siteRealtimeStill()) return;
          if (!value || !endDate) {
            var $preset = $sm(".hours").first();
            if ($preset.length) $preset.trigger("click");
            return;
          }
          interval_update();
        }
      });
      el.click();
    }

    function get_date_range(argument) {
      var start = ""
      var end = ""
      var $custom = $sm('#site-monitor-date');
      if ($custom.hasClass("active-btn")) {
        var date_range = $custom.text() || ""
        var parts = date_range.split(" - ")
        var nowDate = new Date()
        var seconds = nowDate.getSeconds().toString().padStart(2,'0');
        if (parts[0] && parts[1] && parts[0].length >= 17 && parts[1].length >= 17) {
          start = parts[0].slice(0,11) + parts[0].slice(12,17) + ":" + seconds
          end = parts[1].slice(0,11) + parts[1].slice(12,17) + ":" + seconds
        } else {
          var nowMs = nowDate.getTime()
          start = formatDate(nowMs - 3600 * 1000)
          end = formatDate(nowMs)
        }

      } else {
        var hours = Number($sm(".hours.active-btn").data("hour"));
        if (!isFinite(hours) || hours < 1) hours = 1;
        var now = new Date().getTime()
        start = formatDate(now - hours * 3600 * 1000)
        end = formatDate(now)
      }
      return [start, end]
    }

    var $siteRoot = siteMonitorRoot();
    $siteRoot.off('click.veikorSiteMonitor');
    $siteRoot.on('click.veikorSiteMonitor', '#site-monitor-date-tip', function () {
      $(this).addClass("layui-hide")
      $sm('#site-monitor-date').removeClass("layui-hide")
      $sm(".hours").removeClass("active-btn")
      $sm('#site-monitor-date').addClass("active-btn")
      $sm(".time-period").css("width","450px")
      render_date()
    });
    $siteRoot.on('click.veikorSiteMonitor', '.hours', function () {
      $sm(".hours").removeClass("active-btn")
      $(this).addClass("active-btn")
      $sm('#site-monitor-date').removeClass("active-btn")
      $sm('#site-monitor-date').addClass("layui-hide")
      $sm('#site-monitor-date-tip').removeClass("layui-hide")
      $sm(".time-period").css("width","300px")
      interval_update()
    });
    $siteRoot.on('click.veikorSiteMonitor', '#site-monitor-query', function () {
      interval_update()
    })


    function finiteNum(value) {
      var n = Number(value)
      return isFinite(n) ? n : 0
    }

    function statusTip(params, t) {
      if (!params || !params.length || !params[0]) return ""
      var show = formatDate(params[0][1], "YY/MM/DD hh:mm") + " <br>"
      for (var ti = 0; ti < params.length; ti++) {
        var row = params[ti]
        if (!row || typeof row !== "object") continue
        show += layui.admin.textHtml(row[0]) + ": " + finiteNum(row[2]) + t('page.site.monitor.chart.timesUnit') + "<br>"
      }
      return show
    }

    function render_chart(id, option) {
        var box = document.getElementById(id)
        var inner = box ? box.querySelector("div") : null
        if (!inner) return null
        var mychart = echarts.init(inner, layui.echartsTheme);
        mychart.setOption(option);
        mychart.showLoading();
        window.onresize = function() {
          if (!siteRealtimeStill() || !window.chart_ins) return;
          for (var c = 0; c < window.chart_ins.length; c++) {
            if (window.chart_ins[c]) window.chart_ins[c].resize();
          }
        };

        return mychart
    }

    function buildSiteMonitorChartOptions() {
      var t = (veikorI18n && veikorI18n.t) ? veikorI18n.t : function (k) { return k; };
      return [{
      "id": "bandwidth",
      "option" : {
          title: {
              text: t('page.stream.monitor.chart.bandwidth'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) * 8 /200
                  if (v >= 900000) {
                    var b = (v/1000/1000).toFixed(2) + " Gbps"
                  }
                  else if (v >= 900) {
                    var b = (v/1000).toFixed(2) + " Mbps"
                  } else {
                    var b = (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }

                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.stream.monitor.chart.bandwidthLabel') + b
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) * 8 /200
                  if (v >= 900000) {
                    return (v/1000/1000).toFixed(2) + " Gbps"
                  }
                   else if (v >= 900) {
                    return (v/1000).toFixed(2) + " Mbps"
                  } else {
                    return (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }
                }                   
              }
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "traffic",
      "option" : {
          title: {
              text: t('page.stream.monitor.chart.traffic'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) / 1024
                  var trafficText;
                  if (v >= 943718.4) {
                    trafficText = (v/1024/1024).toFixed(2) + " GB"
                  }
                  else if (v >= 921.6) {
                    trafficText = (v / 1024).toFixed(2) + " MB" 
                  } else {
                    trafficText = v.toFixed(2) + " KB"
                  }                  
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.stream.monitor.chart.trafficLabel') + trafficText
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) / 1024
                  if (v >= 943718.4) {
                    return (v/1024/1024).toFixed(2) + " GB"
                  }
                  else if (v >= 921.6) {
                    return (v / 1024).toFixed(2) + " MB" 
                  } else {
                    return v.toFixed(2) + " KB"
                  }
                }
              }
  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "req",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.reqCount'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.site.monitor.chart.reqCountLabel') + value
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',       
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "qps",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.qps'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.site.monitor.chart.qpsLabel') + (isFinite(Number(value)) ? Number(value) : 0).toFixed(1)
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',       
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "req-cache-status",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.reqHitRate'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.site.monitor.chart.reqHitRateLabel') + value + "%"
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',
              axisLabel: {
                formatter: '{value} %'
              }
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "byte-cache-status",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.byteHitRate'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.site.monitor.chart.byteHitRateLabel') + value + "%"
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',
              axisLabel: {
                formatter: '{value} %'
              }
          },
          series: [{
              type: 'line',
              data: []
          }]
      }
    },
    {
      "id": "status-4xx",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.status4xx'),
              textStyle: {
                fontSize: 14
              }                
          },
          legend: {
            show: true,     
            data: []     
          },          
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                return statusTip(params, t)
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',
              axisLabel: {
                formatter: function (value) { return value + t('page.site.monitor.chart.timesUnit'); }
              }              
          },
          series: [{
              type: 'line',
              data: []
          }]
      }
    },
    {
      "id": "status-5xx",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.status5xx'),
              textStyle: {
                fontSize: 14
              }  
          },
          legend: {
            show: true,     
            data: []     
          },            
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                return statusTip(params, t)
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',
              axisLabel: {
                formatter: function (value) { return value + t('page.site.monitor.chart.timesUnit'); }
              }              
          },
          series: [{
              type: 'line',
              data: []
          }]
      }
    },
    {
      "id": "backend-bandwidth",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.backendBandwidth'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) * 8 /1000
                  if (v >= 900000) {
                    var b = (v/1000/1000).toFixed(2) + " Gbps"
                  }
                  else if (v >= 921.6) {
                    var b = (v/1000).toFixed(2) + " Mbps"
                  } else {
                    var b = (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }                  
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.stream.monitor.chart.bandwidthLabel') + b
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) * 8 /1000
                  if (v >= 900000) {
                    return (v/1000/1000).toFixed(2) + " Gbps"
                  }

                  else if (v >= 921.6) {
                    return (v/1000).toFixed(2) + " Mbps"
                  } else {
                    return (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }
                }                   
              }
  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "backend-traffic",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.backendTraffic'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) / 1024
                  var trafficText;
                  if (v >= 943718.4) {
                    trafficText = (v/1024/1024).toFixed(2) + " GB"
                  }
                  else if (v >= 921.6) {
                    trafficText = (v / 1024).toFixed(2) + " MB" 
                  } else {
                    trafficText = v.toFixed(2) + " KB"
                  }                   
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.stream.monitor.chart.trafficLabel') + trafficText
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) / 1024
                  if (v >= 943718.4) {
                    return (v/1024/1024).toFixed(2) + " GB"
                  }
                  else if (v >= 921.6) {
                    return (v / 1024).toFixed(2) + " MB" 
                  } else {
                    return v.toFixed(2) + " KB"
                  }
                }
              },  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },  
    {
      "id": "backend-resp-time",
      "option" : {
          title: {
              text: t('page.site.monitor.chart.backendLatency'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + t('page.site.monitor.chart.backendLatencyLabel') + (isFinite(Number(value)) ? Number(value) : 0).toFixed(3) + t('page.site.monitor.chart.secondsUnit')
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  return value + t('page.site.monitor.chart.secondsUnit')
                }                   
              }
  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    }

    ];
    }

    function applySiteMonitorRealtimeChromeI18n() {
      if (!siteRealtimeStill() || !veikorI18n) return;
      var $bc = $('.site-monitor-breadcrumb');
      if ($bc[0]) veikorI18n.applyDataI18n($bc[0]);
      var root = siteMonitorRoot()[0];
      if (root) {
        veikorI18n.applyDataI18n(root);
        $(root).find('[data-i18n-placeholder]').each(function () {
          var key = $(this).attr('data-i18n-placeholder');
          if (key) $(this).attr('placeholder', veikorI18n.t(key));
        });
      }
      var titleEl = document.querySelector('title[data-i18n]');
      if (titleEl) {
        var titleKey = titleEl.getAttribute('data-i18n');
        if (titleKey) document.title = veikorI18n.t(titleKey);
      }
    }

    function refreshSiteMonitorChartsI18n() {
      if (!siteRealtimeStill() || !veikorI18n) return;
      applySiteMonitorRealtimeChromeI18n();
      var prev = window.chart_option || [];
      var next = buildSiteMonitorChartOptions();
      for (var i = 0; i < next.length; i++) {
        if (prev[i] && prev[i].option && window.chart_ins && window.chart_ins[i]) {
          var oldOpt = prev[i].option;
          var oldSeries = oldOpt.series;
          var oldX = oldOpt.xAxis && oldOpt.xAxis.data;
          var oldLegend = oldOpt.legend && oldOpt.legend.data;
          if (Array.isArray(oldSeries) && oldSeries.length > 1) {
            next[i].option.series = oldSeries;
          } else if (oldSeries && oldSeries[0]) {
            next[i].option.series[0].data = oldSeries[0].data || [];
          }
          if (oldX) next[i].option.xAxis.data = oldX;
          if (oldLegend) next[i].option.legend.data = oldLegend;
          window.chart_ins[i].setOption(next[i].option, true);
        }
      }
      window.chart_option = next;
    }
    window.refreshSiteMonitorChartsI18n = refreshSiteMonitorChartsI18n;
    $(document).on('veikor:lang.siteMonitor', refreshSiteMonitorChartsI18n);
    $(document).on('veikor:lang', refreshSiteMonitorChartsI18n);

    window.chart_option = buildSiteMonitorChartOptions();

    // 定时更新
    function interval_update() {
      if (!siteRealtimeStill()) return;

      function get_data(index) {
          var type = window.chart_option[index]["id"]
          var range = get_date_range()
          var start = encodeURI(range[0])
          var end = encodeURI(range[1])
          var domain = $("#LAY_app_body input[name='domains']").val()
          var server_port = $("#LAY_app_body input[name='server_port']").val()
 
          if (!start.match(/[0-9]{4}/)) {
            return
          }
                
          admin.req({
            url: '/monitor/site/realtime?type='+encodeURIComponent(type == null ? '' : type)+'&start='+start+'&end='+end+'&domain='+encodeURIComponent(domain == null ? '' : domain)+'&server_port='+encodeURIComponent(server_port == null ? '' : server_port) //实际使用请改成服务端真实接口
            ,type: "get"
            ,loader: false
            ,done: function(res){
              if (!siteRealtimeStill() || !window.chart_ins || !window.chart_ins[index]) return;
              window.chart_ins[index].hideLoading();
              //登入成功的提示与跳转
              var data = res.data
              if (!Array.isArray(data)) data = []
              var x = []
              var y = []
              var option = window.chart_option[index]["option"]

              //数据为空
              if (data.length == 0) {
                option["xAxis"]["data"] = [0]
                option["series"][0]["data"] = [0]
                window.chart_ins[index].setOption(option,true);                
                return                
              }

              if (type == "status-4xx" || type == "status-5xx") {
                var series = []
                var legend_data = []
                for (j in data) {
                  if (!data[j] || typeof data[j] !== "object") continue
                  var series_data = {"type":"line"}
                  var name = data[j]['name']
                  var value = data[j]['value']
                  var y = []
                  if (!value) value = []

                  var fillX = x.length === 0
                  for (k in value) {
                    if (!value[k] || typeof value[k] !== "object") continue
                    if (fillX) x.push(value[k][0])
                    y.push(value[k][1])
                  }
                  series_data["name"] = name
                  series_data["data"] = y
                  series.push(series_data)
                  legend_data.push({"name":name})
                }

                option["series"] = series
                option["legend"]["data"] = legend_data

              }
              else {
                for (j in data) {
                  if (!data[j] || typeof data[j] !== "object") continue;
                  if (!data[j]) continue
                  x.push(data[j][0])
                  y.push(data[j][1])
                }
                option["series"][0]["data"] = y
              }
              option["xAxis"]["data"] = x
              window.chart_ins[index].setOption(option,true);
            }
          });          
      } 

      // 设置定时，当前tab
      var curr_tab = window.veikorActiveTabIdOr
        ? window.veikorActiveTabIdOr('#component-tabs', 'base')
        : 'base'
      var update_chart
      if (curr_tab === 'quality') {
        update_chart = [4, 5, 6, 7]
      } else if (curr_tab === 'origin') {
        update_chart = [8, 9, 10]
      } else {
        update_chart = [0, 1, 2, 3]
      }

      for (i in update_chart) {
        var p = update_chart[i]
        get_data(p) 
      }

    }

    // 初始化图表
    window.chart_ins = []
    for (i in window.chart_option) {
      if (!window.chart_option[i] || typeof window.chart_option[i] !== "object") continue;
      window.chart_ins[i] = render_chart(window.chart_option[i]["id"], window.chart_option[i]["option"])
    }

    // 开始首tab间隔更新
    interval_update()

    element.on('tab(monitor-tab)', function(data){
      if (!siteRealtimeStill()) return;
      // resize
      for (i in window.chart_ins) {
        window.chart_ins[i].resize();
      }

      // update
      interval_update()

    });

  });
  
  exports('senior', {})
});
