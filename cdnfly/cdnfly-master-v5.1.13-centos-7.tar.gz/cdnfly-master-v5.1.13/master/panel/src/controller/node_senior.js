/**

 @Name：layuiAdmin Echarts集成
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2
    
 */


layui.define(function(exports){
  // 获取节点列表
  var admin = layui.admin
  var $ = layui.$

  //折线图
  layui.use(['admin', 'echarts','laydate','carousel'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,laydate = layui.laydate
    ,element = layui.element
    ,carousel = layui.carousel
    ,element = layui.element
    ,device = layui.device()    
    ,echarts = layui.echarts;

    var nodeRealtimeSeq = (window.__veikorNodeRealtimeSeq = (window.__veikorNodeRealtimeSeq || 0) + 1);

    function monitorRoot() {
      var $body = $('#LAY_app_body');
      var $tab = $body.find('[lay-filter="node-monitor-tab"]').first();
      if ($tab.length) return $tab.closest('#component-tabs');
      return $body.find('#component-tabs').first();
    }
    function $m(sel) {
      return monitorRoot().find(sel);
    }

    function nodeRealtimeStill() {
      if (nodeRealtimeSeq !== window.__veikorNodeRealtimeSeq) return false;
      var path = [];
      try { path = layui.router().path || []; } catch (e) { return false; }
      if (path[0] !== 'node' || path[1] !== 'monitor' || path[2] !== 'realtime') return false;
      var body = document.querySelector('#LAY_app_body');
      return !!(body && body.querySelector('[lay-filter="node-monitor-tab"]'));
    }

    admin.on('hash(node-monitor-realtime-tab)', function(router){
      console.log(window.node_interval)
      if (!window.node_interval) return;
      for (i in window.node_interval) {
        clearInterval(window.node_interval[i])
      }
    });

    var node_ajax = admin.req({
      url: '/nodes?limit=0'
      ,type: "get"
      ,loader: false
      ,done: function(res){
        if (!nodeRealtimeStill() || !res || !res.data) return;
        var data = res.data
        for (i in data) {
          if (!data[i] || typeof data[i] !== "object") continue;
          $m(".nodes").append(layui.admin.optionHtml(data[i]['id'], data[i]['name'], i == 0));
        }

        $m('.nodes').select2({
          placeholder: '选择节点',
          width: 'resolve'
        });

      }
    }); 


    function formatDate(time,format='YY-MM-DD hh:mm:ss'){
        var date = new Date(time);
     
        var year = date.getFullYear(),
            month = date.getMonth()+1,//月份是从0开始的
            day = date.getDate(),
            hour = date.getHours(),
            min = date.getMinutes(),
            sec = date.getSeconds();
        var preArr = Array.apply(null,Array(10)).map(function(elem, index) {
            return '0'+index;
        });//开个长度为10的数组 格式为 ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09"]
     
        var newTime = format.replace(/YY/g,year)
            .replace(/MM/g,preArr[month]||month)
            .replace(/DD/g,preArr[day]||day)
            .replace(/hh/g,preArr[hour]||hour)
            .replace(/mm/g,preArr[min]||min)
            .replace(/ss/g,preArr[sec]||sec);
     
        return newTime;
    };

  var nodeMonitorLaydateInst;
  function render_date() {
    var el = $m('#node-monitor-date')[0];
    if (!el || !nodeRealtimeStill()) return;
    if (nodeMonitorLaydateInst) {
      try { nodeMonitorLaydateInst = null; } catch (e) {}
    }
    nodeMonitorLaydateInst = laydate.render({
      elem: el
      ,type: 'datetime'
      ,range: true
      ,format: 'yyyy-MM-dd (HH:mm)'
      ,value: formatDate(new Date().getTime() - 3600000, 'YY-MM-DD (hh:mm)') + " - " + formatDate(new Date().getTime(), 'YY-MM-DD (hh:mm)')
      ,done: function(value, date, endDate){
        if (!nodeRealtimeStill()) return;
        if (!value || !endDate) {
          var $preset = $m(".hours").first();
          if ($preset.length) {
            $preset.trigger("click");
          }
          return;
        }
        interval_update();
      }
    });
    el.click();
  }

    function nodeSelectEmpty() {
      return $m("select[name='nodes'] option").length === 0;
    }

    function hasNodeSelected() {
      var node = $m("select[name='nodes']").val();
      if (node == null || node === '') return false;
      if (Array.isArray(node) && !node.length) return false;
      return true;
    }

    function get_date_range(argument) {
      var start = ""
      var end = ""
      var $custom = $m('#node-monitor-date');
      if ($custom.hasClass("active-btn")) {
        var date_range = $custom.text() || ""
        var parts = date_range.split(" - ")
        var nowDate = new Date()
        var seconds = nowDate.getSeconds().toString().padStart(2,'0');
        if (parts[0] && parts[1] && parts[0].length >= 17 && parts[1].length >= 17) {
          start = parts[0].slice(0,11) + parts[0].slice(12,17) + ":" + seconds
          end = parts[1].slice(0,11) + parts[1].slice(12,17) + ":" + seconds
        } else {
          var nowMs = nowDate.getTime()
          start = formatDate(nowMs - 3600 * 1000)
          end = formatDate(nowMs)
        }

      } else {
        var hours = Number($m(".hours.active-btn").data("hour"));
        if (!isFinite(hours) || hours < 1) hours = 1;
        var now = new Date().getTime()
        start = formatDate(now - hours * 3600 * 1000)
        end = formatDate(now)
      }
      return [start, end]
    }

    var $root = monitorRoot();
    $root.off('click.veikorNodeMonitor');
    $root.on('click.veikorNodeMonitor', '#node-monitor-date-tip', function () {
      $(this).addClass("layui-hide")
      $m('#node-monitor-date').removeClass("layui-hide")
      $m(".hours").removeClass("active-btn")
      $m('#node-monitor-date').addClass("active-btn")
      render_date()
    });

    $root.on('click.veikorNodeMonitor', '.hours', function () {
      $m(".hours").removeClass("active-btn")
      $(this).addClass("active-btn")
      $m('#node-monitor-date').removeClass("active-btn")
      $m('#node-monitor-date').addClass("layui-hide")
      $m('#node-monitor-date-tip').removeClass("layui-hide")
      interval_update()
    });

    $root.on('click.veikorNodeMonitor', '#node-monitor-query', function () {
      if (nodeSelectEmpty()) {
        if (layui.layer) layui.layer.msg('请先添加节点', {icon: 0});
        return;
      }
      interval_update()
    })


    function resizeNodeCharts() {
      if (!nodeRealtimeStill()) return;
      var root = document.querySelector('#LAY_app_body');
      if (!root || !echarts.getInstanceById) return;
      var nodes = root.querySelectorAll('[_echarts_instance_]');
      for (var c = 0; c < nodes.length; c++) {
        var chart = echarts.getInstanceById(nodes[c].getAttribute('_echarts_instance_'));
        if (chart) chart.resize();
      }
    }

    function tipFixed(value, digits) {
      var n = Number(value)
      if (!isFinite(n)) n = 0
      return n.toFixed(digits)
    }

    function render_chart(id,option) {
        var box = document.getElementById(id)
        var inner = box ? box.querySelector("div") : null
        if (!inner) return null
        var mychart = echarts.init(inner, layui.echartsTheme);
        mychart.setOption(option);
        //mychart.showLoading();
        window.onresize = resizeNodeCharts;
        return mychart
    }

    function eachOwn(coll, fn) {
      if (!coll || typeof coll !== "object") return
      for (var key in coll) {
        if (Object.prototype.hasOwnProperty.call(coll, key)) fn(key, coll[key])
      }
    }

    function pushSeriesPoints(value, x, y, fillX) {
      if (!value || typeof value !== "object") return
      eachOwn(value, function(k, point) {
        if (!point || typeof point !== "object") return
        if (fillX) x.push(point[0])
        y.push(point[1])
      })
    }

    function appendAxis(points, x, y) {
      if (!points || !points.length) return
      for (var j = 0; j < points.length; j++) {
        if (!points[j] || typeof points[j] !== "object") continue
        x.push(points[j][0])
        y.push(points[j][1])
      }
    }

    function tipLines(params, formatValue) {
      if (!params || !params.length || !params[0]) return ""
      var show = formatDate(params[0][1], "YY/MM/DD hh:mm") + " <br>"
      for (var ti = 0; ti < params.length; ti++) {
        var row = params[ti]
        if (!row || typeof row !== "object") continue
        show += layui.admin.textHtml(row[0]) + ": " + formatValue(row[2]) + "<br>"
      }
      return show
    }

    function get_data(type) {
      if (nodeSelectEmpty() || !hasNodeSelected()) {
        return;
      }
      var range = get_date_range()
      var start = range[0]
      var end = range[1]
      if (!start || !end || !String(start).match(/[0-9]{4}/) || !String(end).match(/[0-9]{4}/)) {
        return
      }
      start = encodeURI(start)
      end = encodeURI(end)
      var node = $m("select[name='nodes']").val()

      admin.req({
        url: '/monitor/node/realtime?type='+encodeURIComponent(type == null ? '' : type)+'&start='+start+'&end='+end+'&node='+encodeURIComponent(node == null ? '' : node) //实际使用请改成服务端真实接口
        ,type: "get"
        ,loader: false
        ,done: function(res){
          if (!nodeRealtimeStill() || !res) return;
          var data = res.data
          if (data == null) data = {}
          function seriesPoints(value) {
            var rows = []
            if (!value) return rows
            if (Array.isArray(value)) {
              for (var pi = 0; pi < value.length; pi++) {
                if (value[pi]) rows.push(value[pi])
              }
              return rows
            }
            if (typeof value === "object") {
              for (var pk in value) {
                if (!Object.prototype.hasOwnProperty.call(value, pk) || !value[pk]) continue
                rows.push(value[pk])
              }
            }
            return rows
          }

          if (type == "bandwidth") {
            $(".nic").empty()
            var nicKeys = []
            eachOwn(data, function(nicName) { nicKeys.push(nicName) })
            for (var ni = 0; ni < nicKeys.length; ni++) {
                var $bandwidth = $('<div class="layui-carousel layadmin-carousel layadmin-dataview" data-anim="fade"><div carousel-item id="node-nic-'+ni+'"><div><i class="layui-icon layui-icon-loading1 layadmin-loading"></i></div></div></div>')
                $(".nic").append($bandwidth)
            }

            //轮播切换
            $('.layadmin-carousel').each(function(){
              var othis = $(this);
              carousel.render({
                elem: this
                ,width: '100%'
                ,arrow: 'none'
                ,interval: othis.data('interval')
                ,autoplay: othis.data('autoplay') === true
                ,trigger: (device.ios || device.android) ? 'click' : 'hover'
                ,anim: othis.data('anim')
              });
            });

            for (var ni = 0; ni < nicKeys.length; ni++) {
              var nicName = nicKeys[ni]
              var option = {
                title: {
                    text: nicName,
                    textStyle: {
                      fontSize: 14
                    }  
                },
                legend: {
                  show: true,     
                  data: []     
                },            
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                      return tipLines(params, function(value) {
                        var n = Number(value)
                        if (!isFinite(n)) n = 0
                        var v = n / 1000
                        if (v >= 900) return tipFixed(v / 1000, 2) + " Mbps"
                        return tipFixed(n / 1000, 2) + " Kbps"
                      })
                    },
                },

                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',     
                    axisLabel: {
                      formatter: function (value, index) {
                        var v = value /1000
                        if (v >= 900) {
                          return (v/1000).toFixed(2) + " Mbps"
                        } else {
                          return (value /1000).toFixed(2) + " Kbps"
                        }
                      }                   
                    }
                },
                series: [{
                    type: 'line',
                    data: []
                }]
              }

              var series = []
              var legend_data = []
              var x = []

              var nic_data = data[nicName]
              eachOwn(nic_data, function(j, row) {
                if (!row || typeof row !== "object") return
                var series_data = {"type":"line"}
                var name = row['name']
                var y = []
                pushSeriesPoints(row['data'], x, y, x.length === 0)
                series_data["name"] = name
                series_data["data"] = y
                series.push(series_data)
                legend_data.push({"name":name})
              })

              option["series"] = series
              option["legend"]["data"] = legend_data
              option["xAxis"]["data"] = x

              render_chart("node-nic-"+ni, option)

            }
          } else if (type == "disk_usage") {
            var diskKeys = []
            eachOwn(data, function(diskName) { diskKeys.push(diskName) })
            $(".disk").empty()
            for (var di = 0; di < diskKeys.length; di++) {
                var $disk = $('<div class="layui-carousel layadmin-carousel layadmin-dataview" data-anim="fade"><div carousel-item id="path_'+di+'"><div><i class="layui-icon layui-icon-loading1 layadmin-loading"></i></div></div></div>')
                $(".disk").append($disk)
            }

            //轮播切换
            $('.layadmin-carousel').each(function(){
              var othis = $(this);
              carousel.render({
                elem: this
                ,width: '100%'
                ,arrow: 'none'
                ,interval: othis.data('interval')
                ,autoplay: othis.data('autoplay') === true
                ,trigger: (device.ios || device.android) ? 'click' : 'hover'
                ,anim: othis.data('anim')
              });
            });

            for (var di = 0; di < diskKeys.length; di++) {
              var diskName = diskKeys[di]
              var option = {
                title: {
                    text: "分区 "+diskName,
                    textStyle: {
                      fontSize: 14
                    }  
                },
                legend: {
                  show: true,     
                  data: []     
                },            
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                      return tipLines(params, function(value) {
                        return tipFixed(value, 1) + " %"
                      })
                    },
                },
                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',
                    axisLabel: {
                      formatter: '{value} %'
                    }              
                },
                series: [{
                    type: 'line',
                    data: []
                }]
              }

              var series = []
              var legend_data = []
              var x = []

              var nic_data = data[diskName]
              eachOwn(nic_data, function(j, row) {
                if (!row || typeof row !== "object") return
                var series_data = {"type":"line"}
                var name = row['name']
                var y = []
                pushSeriesPoints(row['data'], x, y, x.length === 0)
                series_data["name"] = name
                series_data["data"] = y
                series.push(series_data)
                legend_data.push({"name":name})
              })

              option["series"] = series
              option["legend"]["data"] = legend_data
              option["xAxis"]["data"] = x

              render_chart("path_"+di, option)
            }
          } else if (type == "nginx_status") {
            var option = {
              title: {
                  text: "Nginx状态",
                  textStyle: {
                    fontSize: 14
                  }  
              },
              legend: {
                show: true,     
                data: []     
              },            
              tooltip: {
                  trigger: 'axis',
                  formatter: function (params) {
                    return tipLines(params, function(value) {
                      var n = Number(value)
                      return (isFinite(n) ? n : 0) + "次"
                    })
                  },
              },
              xAxis: {
                  type: 'category',
                  data:[],
                  axisLabel: {
                    formatter: function (value, index) {
                      return formatDate(value,"MM/DD hh:mm")
                    }
                  }
              },
              yAxis: {
                  type: 'value'           
              },
              series: [{
                  type: 'line',
                  data: []
              }]
            }

            var series = []
            var legend_data = []
            var x = []
            var y = []

            for (j in data) {
              if (!data[j] || typeof data[j] !== "object") continue
              var series_data = {"type":"line"}
              var name = data[j]['name']
              var value = data[j]['data']
              var y = []
              if (!value) value = []

              var fillX = x.length === 0
              for (k in value) {
                if (!value[k] || typeof value[k] !== "object") continue
                if (fillX) x.push(value[k][0])
                y.push(value[k][1])
              }

              series_data["name"] = name
              series_data["data"] = y
              series.push(series_data)
              legend_data.push({"name":name})
            }

            option["series"] = series
            option["legend"]["data"] = legend_data
            option["xAxis"]["data"] = x

            render_chart("nginx-status",option)          

          } else if (type == "tcp_conn") {
            option = {
                title: {
                    text: 'TCP连接数',
                    textStyle: {
                      fontSize: 14
                    }                
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                        if (!params || !params.length || !params[0]) return ""
                        params = params[0];
                        date = params[1]
                        value = params[2]
                        var n = Number(value)
                        return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "连接数: " + (isFinite(n) ? n : 0)
                    },
                },
                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',       
                },
                series: [{
                    type: 'line',
                    data: []
                }]
            }            
            var x = []
            var y = []
            var tcpPoints = seriesPoints(data)
            appendAxis(tcpPoints, x, y)

            option["series"][0]["data"] = y
            option["xAxis"]["data"] = x
            render_chart("tcp-conn",option)   

          } else if (type == "sys_load") {
            // cpu
            option = {
                title: {
                    text: 'CPU使用率',
                    textStyle: {
                      fontSize: 14
                    }                
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                        if (!params || !params.length || !params[0]) return ""
                        params = params[0];
                        date = params[1]
                        value = params[2]
                        return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "使用率: " + tipFixed(value, 1)+" %"
                    },
                },
                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',
                    axisLabel: {
                      formatter: '{value} %'
                    }              
                },
                series: [{
                    type: 'line',
                    data: []
                }]
            }            
            var x = []
            var y = []
            var cpuPoints = seriesPoints(data['cpu'])
            appendAxis(cpuPoints, x, y)

            option["series"][0]["data"] = y
            option["xAxis"]["data"] = x
            render_chart("cpu",option)   

            // mem
            option = {
                title: {
                    text: '内存使用率',
                    textStyle: {
                      fontSize: 14
                    }                
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                        if (!params || !params.length || !params[0]) return ""
                        params = params[0];
                        date = params[1]
                        value = params[2]
                        return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "使用率: " + tipFixed(value, 1) + " %"
                    },
                },
                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',
                    axisLabel: {
                      formatter: '{value} %'
                    }              
                },
                series: [{
                    type: 'line',
                    data: []
                }]
            }            
            var x = []
            var y = []
            var memPoints = seriesPoints(data['mem'])
            appendAxis(memPoints, x, y)

            option["series"][0]["data"] = y
            option["xAxis"]["data"] = x
            render_chart("mem",option)  

            // 负载
            option = {
                title: {
                    text: '系统负载',
                    textStyle: {
                      fontSize: 14
                    }                
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function (params) {
                        if (!params || !params.length || !params[0]) return ""
                        params = params[0];
                        date = params[1]
                        value = params[2]
                        return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "负载: " + tipFixed(value, 1)
                    },
                },
                xAxis: {
                    type: 'category',
                    data:[],
                    axisLabel: {
                      formatter: function (value, index) {
                        return formatDate(value,"MM/DD hh:mm")
                      }
                    }
                },
                yAxis: {
                    type: 'value',       
                },
                series: [{
                    type: 'line',
                    data: []
                }]
            }            
            var x = []
            var y = []
            var loadPoints = seriesPoints(data['load'])
            appendAxis(loadPoints, x, y)

            option["series"][0]["data"] = y
            option["xAxis"]["data"] = x
            render_chart("load",option)  

          }
        }
      })       
    }



    $.when(node_ajax).then(function () {
      if (nodeSelectEmpty()) {
        return;
      }
      if (!hasNodeSelected()) {
        var $sel = $m("select[name='nodes']");
        var first = $sel.find('option').first().val();
        if (first != null && first !== '') $sel.val(first).trigger('change');
      }
      interval_update()
    })

    window.node_interval = []
    function  interval_update() {
      if (!nodeRealtimeStill()) return;
      // 清理定时
      for (k in window.node_interval) {
        clearInterval(window.node_interval[k])
      }

      window.node_interval = []

      var curr_tab = $m(".layui-tab-title .layui-this").text()
      if (curr_tab == "带宽") {
        get_data("bandwidth")        

      } else if (curr_tab == "连接") {
        get_data("nginx_status")
        get_data("tcp_conn")

      } else if (curr_tab == "负载") {
        get_data("sys_load")     

      } else {
        get_data("disk_usage")
      }

    }

    element.on('tab(node-monitor-tab)', function(data){
      if (!nodeRealtimeStill()) return;
      resizeNodeCharts();
      interval_update()

    });

  });
  
  exports('node_senior', {})
});