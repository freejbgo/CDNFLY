/**

 @Name：layuiAdmin Echarts集成
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2
    
 */


layui.define(function(exports){
  // 获取端口列表
  var admin = layui.admin
  var $ = layui.$
  var streamRealtimeSeq = (window.__veikorStreamRealtimeSeq = (window.__veikorStreamRealtimeSeq || 0) + 1);
  function streamRealtimeStill() {
    if (streamRealtimeSeq !== window.__veikorStreamRealtimeSeq) return false;
    var path = [];
    try { path = layui.router().path || []; } catch (e) { return false; }
    if (path[0] !== 'stream' || path[1] !== 'monitor' || path[2] !== 'realtime') return false;
    var body = document.querySelector('#LAY_app_body');
    return !!(body && body.querySelector('[lay-filter="stream-monitor-tab"]'));
  }

  admin.on('hash(stream_monitor)', function(router){
    if (!window.stream_chart_interval) return;
    for (i in window.stream_chart_interval) {
      clearInterval(window.stream_chart_interval[i])
    }
  });

  admin.req({
    url: '/streams?limit=0'
    ,type: "get"
    ,loader: false
    ,done: function(res){
      if (!streamRealtimeStill() || !res || !res.data) return;
      var data = res.data
      function streamListenRows(raw) {
        if (raw == null || raw === "") return [];
        if (Array.isArray(raw)) return raw;
        if (typeof raw === "object") return [raw];
        if (typeof raw !== "string") return [];
        var parsed = null;
        try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === "object") return [parsed];
        var rows = [];
        var parts = raw.split(/\s+/);
        for (var k = 0; k < parts.length; k++) {
          if (!parts[k]) continue;
          var bits = parts[k].split("/");
          if (!bits[0]) continue;
          rows.push({port: bits[0], protocol: bits.length > 1 && bits[1] ? bits[1] : "tcp"});
        }
        return rows;
      }
      for (i in data) {
        if (!data[i] || typeof data[i] !== "object") continue;
        var listen = streamListenRows(data[i]['listen']);
        for (j in listen) {
          if (!listen[j] || typeof listen[j] !== "object") continue;
          var port = listen[j]['port'];
          var protocol = listen[j]['protocol'];
          if (port == null || protocol == null || protocol === "") continue;
          var port_protocol = port + "/" + String(protocol).toUpperCase();
          $(".ports").append(layui.admin.optionHtml(port_protocol, port_protocol));
        }
      }

      $('.ports').select2({
        placeholder: '选择端口',
        allowClear: true,
        width: 'resolve'
      });

    }
  }); 

  //区块轮播切换
  layui.use(['admin', 'carousel'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,carousel = layui.carousel
    ,element = layui.element
    ,device = layui.device();

    //轮播切换
    $('.layadmin-carousel').each(function(){
      var othis = $(this);
      carousel.render({
        elem: this
        ,width: '100%'
        ,arrow: 'none'
        ,interval: othis.data('interval')
        ,autoplay: othis.data('autoplay') === true
        ,trigger: (device.ios || device.android) ? 'click' : 'hover'
        ,anim: othis.data('anim')
      });
    });

  });


  //折线图
  layui.use(['admin', 'echarts','laydate'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,laydate = layui.laydate
    ,element = layui.element
    ,echarts = layui.echarts;

    function streamMonitorRoot() {
      var $body = $('#LAY_app_body');
      var $tab = $body.find('[lay-filter="stream-monitor-tab"]').first();
      if ($tab.length) return $tab.closest('#component-tabs');
      return $body.find('#component-tabs').first();
    }
    function $stm(sel) {
      return streamMonitorRoot().find(sel);
    }

    function formatDate(time,format='YY-MM-DD hh:mm:ss'){
        var date = new Date(time);
     
        var year = date.getFullYear(),
            month = date.getMonth()+1,//月份是从0开始的
            day = date.getDate(),
            hour = date.getHours(),
            min = date.getMinutes(),
            sec = date.getSeconds();
        var preArr = Array.apply(null,Array(10)).map(function(elem, index) {
            return '0'+index;
        });//开个长度为10的数组 格式为 ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09"]
     
        var newTime = format.replace(/YY/g,year)
            .replace(/MM/g,preArr[month]||month)
            .replace(/DD/g,preArr[day]||day)
            .replace(/hh/g,preArr[hour]||hour)
            .replace(/mm/g,preArr[min]||min)
            .replace(/ss/g,preArr[sec]||sec);
     
        return newTime;
    };

    function render_date() {
      var el = $stm('#stream-monitor-date')[0];
      if (!el || !streamRealtimeStill()) return;
      laydate.render({
        elem: el
        ,type: 'datetime'
        ,range: true
        ,format: 'yyyy-MM-dd (HH:mm)'
        ,value: formatDate(new Date().getTime() - 3600000, 'YY-MM-DD (hh:mm)') + " - " + formatDate(new Date().getTime(), 'YY-MM-DD (hh:mm)')
        ,done: function(value, date, endDate){
          if (!streamRealtimeStill()) return;
          if (!value || !endDate) {
            var $preset = $stm(".hours").first();
            if ($preset.length) $preset.trigger("click");
            return;
          }
          interval_update();
        }
      });
      el.click();
    }

    function get_date_range(argument) {
      var start = ""
      var end = ""
      var $custom = $stm('#stream-monitor-date');
      if ($custom.hasClass("active-btn")) {
        var date_range = $custom.text() || ""
        var parts = date_range.split(" - ")
        var nowDate = new Date()
        var seconds = nowDate.getSeconds().toString().padStart(2,'0');
        if (parts[0] && parts[1] && parts[0].length >= 17 && parts[1].length >= 17) {
          start = parts[0].slice(0,11) + parts[0].slice(12,17) + ":" + seconds
          end = parts[1].slice(0,11) + parts[1].slice(12,17) + ":" + seconds
        } else {
          var nowMs = nowDate.getTime()
          start = formatDate(nowMs - 3600 * 1000)
          end = formatDate(nowMs)
        }

      } else {
        var hours = Number($stm(".hours.active-btn").data("hour"));
        if (!isFinite(hours) || hours < 1) hours = 1;
        var now = new Date().getTime()
        start = formatDate(now - hours * 3600 * 1000)
        end = formatDate(now)
      }
      return [start, end]
    }

    var $streamRoot = streamMonitorRoot();
    $streamRoot.off('click.veikorStreamMonitor');
    $streamRoot.on('click.veikorStreamMonitor', '#stream-monitor-date-tip', function () {
      $(this).addClass("layui-hide")
      $stm('#stream-monitor-date').removeClass("layui-hide")
      $stm(".hours").removeClass("active-btn")
      $stm('#stream-monitor-date').addClass("active-btn")
      render_date()
    });
    $streamRoot.on('click.veikorStreamMonitor', '.hours', function () {
      $stm(".hours").removeClass("active-btn")
      $(this).addClass("active-btn")
      $stm('#stream-monitor-date').removeClass("active-btn")
      $stm('#stream-monitor-date').addClass("layui-hide")
      $stm('#stream-monitor-date-tip').removeClass("layui-hide")
      interval_update()
    });
    $streamRoot.on('click.veikorStreamMonitor', '#stream-monitor-query', function () {
      interval_update()
    })


    function finiteNum(value) {
      var n = Number(value)
      return isFinite(n) ? n : 0
    }

    function render_chart(id, option) {
        var box = document.getElementById(id)
        var inner = box ? box.querySelector("div") : null
        if (!inner) return null
        var mychart = echarts.init(inner, layui.echartsTheme);
        mychart.setOption(option);
        mychart.showLoading();
        window.onresize = function() {
          if (!streamRealtimeStill() || !window.chart_ins) return;
          for (var c = 0; c < window.chart_ins.length; c++) {
            if (window.chart_ins[c]) window.chart_ins[c].resize();
          }
        };

        return mychart
    }

    window.stream_chart_option = [{
      "id": "stream-bandwidth",
      "option" : {
          title: {
              text: '带宽',
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) * 8 /1000
                  if (v >= 900) {
                    var b = (v/1000).toFixed(2) + " Mbps"
                  } else {
                    var b = (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }

                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "带宽: " + b
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) * 8 /1000
                  if (v >= 900) {
                    return (v/1000).toFixed(2) + " Mbps"
                  } else {
                    return (finiteNum(value) * 8 /1000).toFixed(2) + " Kbps"
                  }
                }                   
              }
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "stream-traffic",
      "option" : {
          title: {
              text: '流量',
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]
                  var v = finiteNum(value) / 1024
                  if (v >= 921.6) {
                    var t = (v / 1024).toFixed(2) + " MB" 
                  } else {
                    var t = v.toFixed(2) + " KB"
                  }                  
                  return formatDate(date,"YY/MM/DD hh:mm") + " <br>" + "流量: " + t
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  return formatDate(value,"MM/DD hh:mm")
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) / 1024
                  if (v >= 921.6) {
                    return (v / 1024).toFixed(2) + " MB" 
                  } else {
                    return v.toFixed(2) + " KB"
                  }
                }
              }
  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    
    ]

    // 定时更新
    function interval_update() {
      if (!streamRealtimeStill()) return;
      // 清理定时
      for (k in window.stream_chart_interval) {
        clearInterval(window.stream_chart_interval[k])
      }

      window.stream_chart_interval = []
      function get_data(index) {
          var type = window.stream_chart_option[index]["id"]
          var range = get_date_range()
          var start = encodeURI(range[0])
          var end = encodeURI(range[1])
          var port = $("select[name='ports']").val()
          if (port) {
            port = port.join(" ")
          } else {
            port = ""
          }          
          admin.req({
            url: '/monitor/stream/realtime?type='+encodeURIComponent(type == null ? '' : type)+'&start='+start+'&end='+end+'&port='+encodeURIComponent(port == null ? '' : port) //实际使用请改成服务端真实接口
            ,type: "get"
            ,loader: false
            ,done: function(res){
              if (!streamRealtimeStill() || !window.chart_ins || !window.chart_ins[index]) return;
              window.chart_ins[index].hideLoading();
              //登入成功的提示与跳转
              var data = res.data
              if (!Array.isArray(data)) data = []
              var x = []
              var y = []
              var option = window.stream_chart_option[index]["option"]

              //数据为空
              if (data.length == 0) {
                option["xAxis"]["data"] = [0]
                option["series"][0]["data"] = [0]
                window.chart_ins[index].setOption(option,true);                
                return                
              }

              for (j in data) {
                if (!data[j] || typeof data[j] !== "object") continue;
                if (!data[j]) continue
                x.push(data[j][0])
                y.push(data[j][1])
              }
              option["series"][0]["data"] = y

              option["xAxis"]["data"] = x
              window.chart_ins[index].setOption(option,true);
            }
          });          
      } 

      // 设置定时，当前tab
      var curr_tab = window.veikorActiveTabIdOr
        ? window.veikorActiveTabIdOr('#component-tabs', 'bw-traffic')
        : 'bw-traffic'
      if (curr_tab === 'bw-traffic') {
        var update_chart = [0, 1]
        for (i in update_chart) {
          var p = update_chart[i]
          get_data(p)
        }
      }

    }

    // 初始化图表
    window.chart_ins = []
    for (i in window.stream_chart_option) {
      if (!window.stream_chart_option[i] || typeof window.stream_chart_option[i] !== "object") continue;
      window.chart_ins[i] = render_chart(window.stream_chart_option[i]["id"], window.stream_chart_option[i]["option"])
    }

    // 开始首tab间隔更新
    interval_update()

    element.on('tab(stream-monitor-tab)', function(data){
      if (!streamRealtimeStill()) return;
      // resize
      for (i in window.chart_ins) {
        window.chart_ins[i].resize();
      }

      // update
      interval_update()    

      $(".ports-select").removeClass("layui-hide")    

    });

  });
  
  exports('stream_senior', {})
});