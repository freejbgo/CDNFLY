layui.define(['admin', 'form', 'user', 'veikorI18n'], function(exports){
  var $ = layui.$
  ,setter = layui.setter
  ,admin = layui.admin
  ,form = layui.form
  ,veikorI18n = layui.veikorI18n;

  var policySeq = 0;

  function resetCaptchaButton() {
    if (window.count_down_interval) {
      clearInterval(window.count_down_interval);
      window.count_down_interval = null;
    }
    $("#LAY-user-login-captcha").removeClass("layui-btn-disabled").text("获取验证码");
  }

  function loginDest(search, fallback) {
    var raw = search && search.redirect;
    if (!raw) return fallback;
    try {
      var next = decodeURIComponent(String(raw));
      if (next.charAt(0) === '/') return next;
    } catch (e) {}
    return fallback;
  }

  window.refresh_img = function(ele) {
    ele.src = '/common/captcha?t=' + new Date().getTime();
  };

  function wait_60s() {
    window.second_total = window.second_total - 1;
    $("#LAY-user-login-captcha").text(window.second_total + "秒后可重发");
    if (window.second_total <= 0) {
      $("#LAY-user-login-captcha").text("获取手机验证码");
      $("#LAY-user-login-captcha").removeClass("layui-btn-disabled");
      clearInterval(window.count_down_interval);
      window.count_down_interval = null;
    }
  }

  window.send_sms = function(ele) {
    var code = $(ele).val();
    if (code.length !== 4) return;
    var account = $("input[name='account']").val();
    admin.req({
      url: '/phone-captcha'
      ,data: JSON.stringify({"account": account, "code": code})
      ,type: "post"
      ,fail: function() { $(".captcha-img").click(); }
      ,contentType: "application/json"
      ,dataType: "json"
      ,done: function(res){
        if (res.code == 0) {
          window.second_total = 60;
          $("#LAY-user-login-captcha").addClass("layui-btn-disabled");
          window.count_down_interval = setInterval(wait_60s, 1000);
          layer.closeAll();
          layer.msg("验证码已发送到您的手机，请收到后输入继续注册");
        }
      }
    });
  };

  function boot() {
    resetCaptchaButton();
    var search = (layui.router().search) || {};
    var access_token = search.access_token;
    var username = search.username;
    var uid = search.uid;

    veikorI18n.applyAuthPage('login');
    veikorI18n.bindLangSelect();

    $('#veikor-pw-toggle').off('click.veikorPw').on('click.veikorPw', function(){
      var $pw = $('#LAY-user-login-password');
      var $btn = $(this);
      if (!$btn.data('show')) $btn.data('show', $.trim($btn.text()) || '显示');
      if (!$btn.data('hide')) $btn.data('hide', '隐藏');
      var showing = $pw.attr('type') === 'text';
      $pw.attr('type', showing ? 'password' : 'text');
      $btn.text(showing ? $btn.data('show') : $btn.data('hide'));
      $btn.attr('aria-label', $btn.text());
    });

    $("#LAY-user-login-username").focus();

    $("input[name='account']").off('change.veikorLogin').on('change.veikorLogin', function() {
      var account = $(this).val();
      var seq = ++policySeq;
      resetCaptchaButton();
      if (!account) {
        $(".captcha-verify").addClass("layui-hide");
        $("#LAY-user-login-captcha").off('click');
        return;
      }
      admin.req({
        url: '/user/login-policy?account=' + encodeURIComponent(account)
        ,type: "get"
        ,contentType: "application/json"
        ,dataType: "json"
        ,done: function(res){
          if (seq !== policySeq) return;
          var data = res.data || {};
          var login_captcha = data.login_captcha;
          var phone = data.phone;
          var email = data.email;
          $(".captcha-verify").toggleClass("layui-hide", !login_captcha);
          $("#LAY-user-login-captcha").off('click');
          if (login_captcha === "sms") {
            $("input[name='captcha']").attr("placeholder", phone + "验证码");
            $("#LAY-user-login-captcha").on('click', function() {
              layer.open({
                type: 1, title: false, closeBtn: 0, shadeClose: true,
                content: '<div class="layui-form-item"><img onclick="refresh_img(this)" class="captcha-img" style="cursor:pointer;margin:-5px 10px 0 20px;width:100px;float:left;" src="/common/captcha"><input oninput="send_sms(this)" style="margin:15px 20px 0 0;width:200px;" type="text" name="code" autocomplete="off" placeholder="输入验证码获取手机短信" class="layui-input"></div>'
              });
              $("input[name='code']").focus();
            });
          } else if (login_captcha === "email") {
            $("input[name='captcha']").attr("placeholder", email + "验证码");
            $("#LAY-user-login-captcha").on('click', function() {
              admin.req({
                url: '/email-captcha'
                ,type: "post"
                ,data: JSON.stringify({account: account})
                ,contentType: "application/json"
                ,dataType: "json"
                ,done: function(){
                  layer.msg('验证码已发送至你的邮箱，请注意查收', {offset: '15px', icon: 1, time: 1000});
                }
              });
            });
          }
        }
      });
    });

    veikorI18n.refreshSysName();

    if (access_token) {
      access_token = access_token.replace(/_/g, "/").replace(/,/g, "=");
      layui.data(setter.tableName, {key: setter.request.tokenName, value: access_token});
      layui.data(setter.tableName, {key: "username", value: username});
      layui.data(setter.tableName, {key: "uid", value: uid});
      layui.data(setter.tableName, {key: "user_type", remove: true});
      location.href = "/console/index.html#/user_home";
      return;
    }

    form.render();

    $(document).off('keyup.veikorLogin').on('keyup.veikorLogin', function(event){
      if (event.keyCode !== 13) return;
      if (!document.getElementById('LAY-user-login')) return;
      if (event.target && $(event.target).closest('.layui-layer').length) return;
      $("#login").click();
    });

    form.on('submit(LAY-user-login-submit)', function(obj){
      admin.req({
        url: '/login'
        ,data: JSON.stringify({
          account: obj.field.account,
          password: obj.field.password,
          code: obj.field.code,
          captcha: obj.field.captcha
        })
        ,type: "post"
        ,fail: function(res) {
          $("#LAY-user-get-vercode").click();
          if (!res) return;
          if (res.code === "user_login-7" || res.code === "user_login-8" || res.code === "user_login-12") {
            $(".code").removeClass("layui-hide");
          }
        }
        ,contentType: "application/json"
        ,dataType: "json"
        ,done: function(res){
          if (!res || !res.data) return;
          layui.data(setter.tableName, {key: setter.request.tokenName, value: res.data.access_token});
          layui.data(setter.tableName, {key: "username", value: res.data.username});
          layui.data(setter.tableName, {key: "uid", value: res.data.uid});
          layui.data(setter.tableName, {key: "user_type", value: res.data.type});
          layer.msg('登入成功', {offset: '15px', icon: 1, time: 1000}, function(){
            var titles = layui.data('layuiAdmin');
            var live = (layui.router().search) || {};
            var isAdmin = res.data.type == 1;
            var consoleTitle = isAdmin ? titles.admin_console_title : titles.user_console_title;
            if (consoleTitle) $("title").text(consoleTitle);
            location.hash = loginDest(live, isAdmin ? '/home' : '/user_home');
          });
        }
      });
    });

    $('#LAY-user-login').css('display', 'block');
  }

  exports('loginPage', { boot: boot });
});
