layui.define(['admin', 'form', 'user', 'veikorI18n'], function(exports){
  var $ = layui.$
  ,setter = layui.setter
  ,admin = layui.admin
  ,form = layui.form
  ,veikorI18n = layui.veikorI18n;

  var policySeq = 0;

  function resetCaptchaButton() {
    if (window.count_down_interval) {
      clearInterval(window.count_down_interval);
      window.count_down_interval = null;
    }
    $("#LAY-user-login-captcha").removeClass("layui-btn-disabled").text(veikorI18n.t('login.captchaBtn'));
  }

  function loginDest(search, fallback) {
    var raw = search && search.redirect;
    if (!raw) return fallback;
    try {
      var next = decodeURIComponent(String(raw)).replace(/[\u0000-\u001F\u007F]/g, '');
      if (next.charAt(0) !== '/') return fallback;
      if (next.charAt(1) === '/' || next.charAt(1) === '\\') return fallback;
      var hash = '';
      var hashAt = next.indexOf('#');
      if (hashAt >= 0) {
        hash = next.slice(hashAt);
        next = next.slice(0, hashAt);
      }
      var query = '';
      var qAt = next.indexOf('?');
      if (qAt >= 0) {
        query = next.slice(qAt);
        next = next.slice(0, qAt);
      }
      // 中间空段拼不回真实视图。末尾斜杠要留下，系统设置这类页面靠它找到 index
      var trailing = /\/$/.test(next);
      var parts = next.split('/');
      var kept = [];
      var i;
      for (i = 0; i < parts.length; i++) {
        if (parts[i]) kept.push(parts[i]);
      }
      var bare = '/' + kept.join('/');
      var probe = bare;
      while (/\/index$/.test(probe)) probe = probe.replace(/\/index$/, '');
      if (!kept.length || /^\/user\/(login|reg|forget)$/.test(probe)) return fallback;
      return bare + (trailing ? '/' : '') + query + hash;
    } catch (e) {}
    return fallback;
  }

  function refresh_img(ele) {
    if (!ele) return;
    ele.src = '/common/captcha?t=' + new Date().getTime();
  }

  function wait_60s() {
    if (!document.getElementById('login')) {
      clearInterval(window.count_down_interval);
      window.count_down_interval = null;
      return;
    }
    window.second_total = window.second_total - 1;
    $("#LAY-user-login-captcha").text(veikorI18n.fmt('auth.resendIn', {n: window.second_total}));
    if (window.second_total <= 0) {
      $("#LAY-user-login-captcha").text(veikorI18n.t('login.captchaBtn'));
      $("#LAY-user-login-captcha").removeClass("layui-btn-disabled");
      clearInterval(window.count_down_interval);
      window.count_down_interval = null;
    }
  }

  function send_sms(ele) {
    if (!document.getElementById('login')) return;
    var code = $(ele).val();
    if (code.length !== 4) return;
    var account = $("input[name='account']").val();
    admin.req({
      url: '/phone-captcha'
      ,data: JSON.stringify({"account": account, "code": code})
      ,type: "post"
      ,fail: function() {
        if (!document.getElementById('login')) return;
        $(".captcha-img").click();
      }
      ,contentType: "application/json"
      ,dataType: "json"
      ,done: function(res){
        if (!document.getElementById('login')) return;
        if (res && res.code == 0) {
          window.second_total = 60;
          $("#LAY-user-login-captcha").addClass("layui-btn-disabled");
          if (window.count_down_interval) clearInterval(window.count_down_interval);
          window.count_down_interval = setInterval(wait_60s, 1000);
          layer.closeAll();
          layer.msg(veikorI18n.t('login.smsSent'));
        }
      }
    });
  }

  function boot() {
    // 注册、找回密码和个人资料也会占用这两个全局函数，回到登录页时要换回登录自己的
    policySeq++;
    window.refresh_img = refresh_img;
    window.send_sms = send_sms;
    if (layui.layer) layui.layer.closeAll('page');
    resetCaptchaButton();
    var search = (layui.router().search) || {};
    var access_token = search.access_token;
    var username = search.username;
    var uid = search.uid;

    veikorI18n.applyAuthPage('login');
    veikorI18n.bindLangSelect();

    $('#veikor-pw-toggle').off('click.veikorPw').on('click.veikorPw', function(){
      var $pw = $('#LAY-user-login-password');
      var $btn = $(this);
      if (!$btn.data('show')) $btn.data('show', $.trim($btn.text()) || '显示');
      if (!$btn.data('hide')) $btn.data('hide', '隐藏');
      var showing = $pw.attr('type') === 'text';
      $pw.attr('type', showing ? 'password' : 'text');
      $btn.text(showing ? $btn.data('show') : $btn.data('hide'));
      $btn.attr('aria-label', $btn.text());
    });

    $("#LAY-user-login-username").focus();

    $("input[name='account']").off('change.veikorLogin').on('change.veikorLogin', function() {
      var account = $(this).val();
      var seq = ++policySeq;
      resetCaptchaButton();
      // 先解开上一个账号的按钮，避免策略还没回来时点到旧账号的短信或邮箱
      $("#LAY-user-login-captcha").off('click');
      $(".captcha-verify").addClass("layui-hide");
      $('#LAY-user-login').removeAttr('data-veikor-login-captcha data-veikor-login-phone data-veikor-login-email');
      if (layui.layer) layui.layer.closeAll('page');
      if (!account) return;
      admin.req({
        url: '/user/login-policy?account=' + encodeURIComponent(account)
        ,type: "get"
        ,loader: false
        ,error_show: false
        ,contentType: "application/json"
        ,dataType: "json"
        ,done: function(res){
          if (seq !== policySeq) return;
          if (!document.getElementById('login') || !res) return;
          var data = res.data || {};
          var login_captcha = data.login_captcha;
          var phone = data.phone;
          var email = data.email;
          var $root = $('#LAY-user-login');
          if (login_captcha) {
            $root.attr('data-veikor-login-captcha', login_captcha);
            $root.attr('data-veikor-login-phone', phone == null ? '' : String(phone));
            $root.attr('data-veikor-login-email', email == null ? '' : String(email));
          } else {
            $root.removeAttr('data-veikor-login-captcha data-veikor-login-phone data-veikor-login-email');
          }
          $(".captcha-verify").toggleClass("layui-hide", !login_captcha);
          $("#LAY-user-login-captcha").off('click');
          if (login_captcha === "sms") {
            $("input[name='captcha']").attr("placeholder", (phone == null ? '' : String(phone)) + veikorI18n.t('login.codeSuffix'));
            $("#LAY-user-login-captcha").on('click', function() {
              if ($(this).hasClass('layui-btn-disabled')) return;
              layer.open({
                type: 1, title: false, closeBtn: 0, shadeClose: true,
                content: veikorI18n.smsCaptchaLayerHtml()
              });
              $("input[name='code']").focus();
            });
          } else if (login_captcha === "email") {
            $("input[name='captcha']").attr("placeholder", (email == null ? '' : String(email)) + veikorI18n.t('login.codeSuffix'));
            $("#LAY-user-login-captcha").on('click', function() {
              if ($(this).hasClass('layui-btn-disabled')) return;
              admin.req({
                url: '/email-captcha'
                ,type: "post"
                ,data: JSON.stringify({account: account})
                ,contentType: "application/json"
                ,dataType: "json"
                ,done: function(){
                  if (!document.getElementById('login')) return;
                  layer.msg(veikorI18n.t('login.emailSent'), {offset: '15px', icon: 1, time: 1000});
                }
              });
            });
          }
        }
      });
    });

    veikorI18n.refreshSysName();

    if (access_token) {
      access_token = access_token.replace(/_/g, "/").replace(/,/g, "=");
      layui.data(setter.tableName, {key: setter.request.tokenName, value: access_token});
      layui.data(setter.tableName, {key: "username", value: username});
      layui.data(setter.tableName, {key: "uid", value: uid});
      layui.data(setter.tableName, {key: "user_type", remove: true});
      location.href = "/console/index.html#/user_home";
      return;
    }

    form.render();

    $(document).off('keyup.veikorLogin').on('keyup.veikorLogin', function(event){
      if (event.keyCode !== 13) return;
      if (!document.getElementById('login')) return;
      if (event.target && $(event.target).closest('.layui-layer').length) return;
      var tag = (event.target && event.target.tagName) || '';
      if (tag === 'BUTTON' || tag === 'A' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      $("#login").click();
    });

    form.on('submit(LAY-user-login-submit)', function(obj){
      admin.req({
        url: '/login'
        ,data: JSON.stringify({
          account: obj.field.account,
          password: obj.field.password,
          code: obj.field.code,
          captcha: obj.field.captcha
        })
        ,type: "post"
        ,fail: function(res) {
          if (!document.getElementById('login')) return;
          $("#LAY-user-get-vercode").click();
          if (!res) return;
          if (res.code === "user_login-7" || res.code === "user_login-8" || res.code === "user_login-12") {
            $(".code").removeClass("layui-hide");
          }
        }
        ,contentType: "application/json"
        ,dataType: "json"
        ,done: function(res){
          if (!res || !res.data || !res.data.access_token) return;
          layui.data(setter.tableName, {key: setter.request.tokenName, value: res.data.access_token});
          layui.data(setter.tableName, {key: "username", value: res.data.username});
          layui.data(setter.tableName, {key: "uid", value: res.data.uid});
          layui.data(setter.tableName, {key: "user_type", value: res.data.type});
          layer.msg(veikorI18n.t('login.success'), {offset: '15px', icon: 1, time: 1000}, function(){
            var live = (layui.router().search) || {};
            var isAdmin = res.data.type == 1;
            location.hash = loginDest(live, isAdmin ? '/home' : '/user_home');
            if (layui.veikorI18n) layui.veikorI18n.applyConsoleTitle();
          });
        }
      });
    });

    $('#LAY-user-login').css('display', 'block');
  }

  exports('loginPage', { boot: boot });
});
