/**

 @Name：layuiAdmin Echarts集成
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2
    
 */


layui.define(function(exports){
    
  //区块轮播切换
  layui.use(['admin', 'carousel'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,carousel = layui.carousel
    ,element = layui.element
    ,table = layui.table
    ,device = layui.device();

    //轮播切换
    $('.layadmin-carousel').each(function(){
      var othis = $(this);
      carousel.render({
        elem: this
        ,width: '100%'
        ,arrow: 'none'
        ,interval: othis.data('interval')
        ,autoplay: othis.data('autoplay') === true
        ,trigger: (device.ios || device.android) ? 'click' : 'hover'
        ,anim: othis.data('anim')
      });
    });

  });


  //折线图
  layui.use(['admin', 'echarts','laydate', 'veikorI18n'], function(){
    var $ = layui.$
    ,admin = layui.admin
    ,laydate = layui.laydate
    ,element = layui.element
    ,table = layui.table
    ,echarts = layui.echarts
    ,veikorI18n = layui.veikorI18n;

    var siteUsageSeq = (window.__veikorSiteUsageSeq = (window.__veikorSiteUsageSeq || 0) + 1);

    function siteUsageRoot() {
      var $body = $('#LAY_app_body');
      var $tab = $body.find('[lay-filter="site-usage-tab"]').first();
      if ($tab.length) return $tab.closest('#component-tabs');
      return $body.find('#component-tabs').first();
    }
    function $su(sel) {
      return siteUsageRoot().find(sel);
    }

    function siteUsageStill() {
      if (siteUsageSeq !== window.__veikorSiteUsageSeq) return false;
      var path = [];
      try { path = layui.router().path || []; } catch (e) { return false; }
      if (path[0] !== 'site' || path[1] !== 'monitor' || path[2] !== 'usage') return false;
      var body = document.querySelector('#LAY_app_body');
      return !!(body && body.querySelector('[lay-filter="site-usage-tab"]'));
    }

    function formatDate(time,format='YY-MM-DD hh:mm:ss'){
        var date = new Date(time);
     
        var year = date.getFullYear(),
            month = date.getMonth()+1,//月份是从0开始的
            day = date.getDate(),
            hour = date.getHours(),
            min = date.getMinutes(),
            sec = date.getSeconds();
        var preArr = Array.apply(null,Array(10)).map(function(elem, index) {
            return '0'+index;
        });//开个长度为10的数组 格式为 ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09"]
     
        var newTime = format.replace(/YY/g,year)
            .replace(/MM/g,preArr[month]||month)
            .replace(/DD/g,preArr[day]||day)
            .replace(/hh/g,preArr[hour]||hour)
            .replace(/mm/g,preArr[min]||min)
            .replace(/ss/g,preArr[sec]||sec);
     
        return newTime;
    };

    function format_bandwidth(value) {
      var n = Number(value)
      if (!isFinite(n)) n = 0
      var v = n * 8 /200
      if (v >= 900000) {
        return (v/1000/1000).toFixed(2) + " Gbps"
      } else if (v >= 921.6) {
        return (v/1000).toFixed(2) + " Mbps"
      } else {
        return v.toFixed(2) + " Kbps"
      }
    }

    function render_date() {
      var el = $su('#site-usage-date')[0];
      if (!el || !siteUsageStill()) return;
      laydate.render({
        elem: el
        ,type: 'date'
        ,range: true
        ,format: 'yyyy-MM-dd'
        ,value: formatDate(new Date().getTime(), 'YY-MM-DD') + " - " + formatDate(new Date().getTime()+3600*1000*24, 'YY-MM-DD')
        ,done: function(value, date, endDate){
          if (!siteUsageStill()) return;
          if (!value || !endDate) {
            var $preset = $su(".hours").first();
            if ($preset.length) $preset.trigger("click");
            return;
          }
          interval_update();
        }
      });
      el.click();
    }

    function get_date_range(argument) {
      var start = ""
      var end = ""
      var $custom = $su('#site-usage-date');
      if ($custom.hasClass("active-btn")) {
        var date_range = $custom.text() || ""
        var parts = date_range.split(" - ")
        if (parts[0] && parts[1]) {
          start = parts[0]
          end = parts[1]
        } else {
          start = formatDate(new Date().getTime(), 'YY-MM-DD')
          end = formatDate(new Date().getTime()+3600*1000*24, 'YY-MM-DD')
        }

      } else {
        var day = $su(".hours.active-btn").data("day")
        if (day == "today") {
          start = formatDate(new Date().getTime(), 'YY-MM-DD')
          end = formatDate(new Date().getTime()+3600*1000*24, 'YY-MM-DD')

        } else if (day == "yesterday") {
          start = formatDate(new Date().getTime() - 3600*1000*24, 'YY-MM-DD')
          end = formatDate(new Date().getTime(), 'YY-MM-DD')

        } else {
          var dayN = parseInt(day, 10);
          if (!isFinite(dayN) || dayN < 1) dayN = 7;
          start = formatDate(new Date().getTime() - 3600*1000*24*dayN, 'YY-MM-DD')
          end = formatDate(new Date().getTime()+3600*1000*24, 'YY-MM-DD')
        }

      }
      return [start, end]
    }

    var $usageRoot = siteUsageRoot();
    $usageRoot.off('click.veikorSiteUsage');
    $usageRoot.on('click.veikorSiteUsage', '#site-usage-date-tip', function () {
      $(this).addClass("layui-hide")
      $su('#site-usage-date').removeClass("layui-hide")
      $su(".hours").removeClass("active-btn")
      $su('#site-usage-date').addClass("active-btn")
      render_date()
    });
    $usageRoot.on('click.veikorSiteUsage', '.hours', function () {
      $su(".hours").removeClass("active-btn")
      $(this).addClass("active-btn")
      $su('#site-usage-date').removeClass("active-btn")
      $su('#site-usage-date').addClass("layui-hide")
      $su('#site-usage-date-tip').removeClass("layui-hide")
      interval_update()
    });
    $usageRoot.on('click.veikorSiteUsage', '#site-usage-query', function () {
      interval_update()
    })


    function finiteNum(value) {
      var n = Number(value)
      return isFinite(n) ? n : 0
    }

    function render_chart(id, option) {
        var box = document.getElementById(id)
        var inner = box ? box.querySelector("div") : null
        if (!inner) return null
        var mychart = echarts.init(inner, layui.echartsTheme);
        mychart.setOption(option);
        mychart.showLoading();
        window.onresize = function() {
          if (!siteUsageStill() || !window.chart_ins) return;
          for (var c = 0; c < window.chart_ins.length; c++) {
            if (window.chart_ins[c]) window.chart_ins[c].resize();
          }
        };

        return mychart
    }

    function formatTrafficValue(value) {
      var v = finiteNum(value) / 1024;
      if (v >= 943718.4) {
        return (v / 1024 / 1024).toFixed(2) + " GB";
      } else if (v >= 921.6) {
        return (v / 1024).toFixed(2) + " MB";
      }
      return v.toFixed(2) + " KB";
    }

    function buildSiteUsageChartOptions() {
      var t = veikorI18n.t;
      return [{
      "id": "bandwidth",
      "option" : {
          title: {
              text: t('page.stream.monitor.chart.bandwidth'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  name = params[0]
                  date = params[1]
                  value = params[2]

                  var b = format_bandwidth(value)
                  var format = "YY/MM/DD hh:mm"
                  if (typeof date === "string" && date.length == 10) {
                    format = "YY/MM/DD"
                  }
                  return formatDate(date,format) + " <br>" + t('page.stream.monitor.chart.bandwidthLabel') + b
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  var format = "MM/DD hh:mm"
                  if (typeof value === "string" && value.length == 10) {
                    format = "MM/DD 00:00"
                  }
                  return formatDate(value,format)
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  return format_bandwidth(value)
                }                   
              }
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    },
    {
      "id": "traffic",
      "option" : {
          title: {
              text: t('page.stream.monitor.chart.traffic'),
              textStyle: {
                fontSize: 14
              }                
          },
          tooltip: {
              trigger: 'axis',
              formatter: function (params) {
                  if (!params || !params.length || !params[0]) return "";
                  params = params[0];
                  date = params[1]
                  value = params[2]
                  var format = "YY/MM/DD hh:mm"
                  if (typeof date === "string" && date.length == 10) {
                    format = "YY/MM/DD"
                  }
                  return formatDate(date,format) + " <br>" + t('page.stream.monitor.chart.trafficLabel') + formatTrafficValue(value)
              },
          },
          xAxis: {
              type: 'category',
              data:[],
              axisLabel: {
                formatter: function (value, index) {
                  var format = "MM/DD hh:mm"
                  if (typeof value === "string" && value.length == 10) {
                    format = "MM/DD 00:00"
                  }
                  return formatDate(value,format)
                }
              }
          },
          yAxis: {
              type: 'value',     
              axisLabel: {
                formatter: function (value, index) {
                  var v = finiteNum(value) / 1024
                  if (v >= 943718.4) {
                    return (v / 1024 /1024).toFixed(2) + " GB" 
                  } else if (v >= 921.6) {
                    return (v / 1024).toFixed(2) + " MB" 
                  } else {
                    return v.toFixed(2) + " KB"
                  }
                }
              }
  
          },
          series: [{
              type: 'line',
              data: []
          }]
      }

    }

    ];
    }

    function usageBandwidthTableCols() {
      var t = veikorI18n.t;
      return [[
        {field:'date', title: t('page.stream.monitor.usage.col.time')}
        ,{field:'value', title: t('page.stream.monitor.chart.bandwidth'), sort: true, templet: function (d) {
          return format_bandwidth(d.value);
        }}
      ]];
    }

    function usageTrafficTableCols() {
      var t = veikorI18n.t;
      return [[
        {field:'date', totalRowText: t('page.stream.monitor.usage.totalTraffic'), title: t('page.stream.monitor.usage.col.time')}
        ,{field:'value', title: t('page.stream.monitor.chart.traffic'), totalRow: true, sort: true, templet: function (d) {
          return formatTrafficValue(d.value);
        }}
      ]];
    }

    function applySiteUsageSeniorChrome() {
      if (!siteUsageStill() || !veikorI18n) return;
      if (window.refreshSiteUsagePageChrome) window.refreshSiteUsagePageChrome();
    }

    function refreshSiteUsageSeniorI18n() {
      if (!siteUsageStill() || !veikorI18n) return;
      applySiteUsageSeniorChrome();
      var prev = window.chart_option || [];
      var next = buildSiteUsageChartOptions();
      for (var i = 0; i < next.length; i++) {
        if (prev[i] && prev[i].option && window.chart_ins && window.chart_ins[i]) {
          var oldSeries = prev[i].option.series && prev[i].option.series[0];
          var oldX = prev[i].option.xAxis && prev[i].option.xAxis.data;
          if (oldSeries) next[i].option.series[0].data = oldSeries.data || [];
          if (oldX) next[i].option.xAxis.data = oldX;
          window.chart_ins[i].setOption(next[i].option, true);
        }
      }
      window.chart_option = next;
      function usageSeniorColsReload(id, colsFn) {
        if (!siteUsageStill()) return;
        if (!table.cache[id]) return;
        var patch = { cols: colsFn() };
        if (typeof window.veikorTableReloadI18nCols === 'function') {
          window.veikorTableReloadI18nCols(id, patch);
        } else {
          table.reload(id, patch);
        }
      }
      usageSeniorColsReload('bandwidth-table', usageBandwidthTableCols);
      usageSeniorColsReload('traffic-table', usageTrafficTableCols);
    }
    window.refreshSiteUsageSeniorI18n = refreshSiteUsageSeniorI18n;

    window.chart_option = buildSiteUsageChartOptions();

    // 定时更新
    function interval_update() {
      if (!siteUsageStill()) return;

      function get_data(index) {
          var type = window.chart_option[index]["id"]
          var range = get_date_range()
          var start = encodeURI(range[0])
          var end = encodeURI(range[1])

          // user_package
          var user_package = $("#LAY_app_body input[name='user_package']").val()

          // domains
          var domains = $("#LAY_app_body input[name='res']").val()     

          // uid
          var uid = undefined
          var select_uid = $("select[name='users']").val()
          if (select_uid) {
            uid = select_uid
          }
          
          var url 
          if (uid) {
            url = '/monitor/usage?cate=site&type='+encodeURIComponent(type == null ? '' : type)+'&start='+start+'&end='+end+'&res='+encodeURIComponent(domains == null ? '' : domains)+'&user_package='+encodeURIComponent(user_package == null ? '' : user_package)+'&uid='+encodeURIComponent(uid)
          } else {
            url = '/monitor/usage?cate=site&type='+encodeURIComponent(type == null ? '' : type)+'&start='+start+'&end='+end+'&res='+encodeURIComponent(domains == null ? '' : domains)+'&user_package='+encodeURIComponent(user_package == null ? '' : user_package)
          }

          admin.req({
            url: url //实际使用请改成服务端真实接口
            ,type: "get"
            ,loader: false
            ,done: function(res){
              if (!siteUsageStill() || !window.chart_ins || !window.chart_ins[index]) return;
              window.chart_ins[index].hideLoading();
              if (type == "bandwidth") {
                var max_value = format_bandwidth(res.max_value)
                var max_95_value = format_bandwidth(res.max_95_value)
                $("#max-value").text(max_value)
                $("#max-95-value").text(max_95_value)
              }

              //登入成功的提示与跳转
              var data = res.data
              if (!Array.isArray(data)) data = []
              var x = []
              var y = []
              var option = window.chart_option[index]["option"]

              // 带宽
              if (index == 0) {
                table.reload("bandwidth-table", {data: data}); //表格重载

              // 流量
              } else {
                table.reload("traffic-table", {data: data}); //表格重载
              }

              //数据为空
              if (data.length == 0) {
                option["xAxis"]["data"] = [0]
                option["series"][0]["data"] = [0]
                window.chart_ins[index].setOption(option,true);
                return                
              }

              for (j in data) {
                if (!data[j] || typeof data[j] !== "object") continue
                x.push(data[j]["date"])
                y.push(data[j]["value"])
              }
              option["series"][0]["data"] = y

              option["xAxis"]["data"] = x
              window.chart_ins[index].setOption(option,true);


            }
          });          
      } 

      // 设置定时，当前tab
      var curr_tab = window.veikorActiveTabIdOr
        ? window.veikorActiveTabIdOr('#component-tabs', 'bw')
        : 'bw'
      if (curr_tab === 'traffic') {
        get_data(1)
      } else {
        get_data(0)
      }
    }

    // 初始化图表
    window.chart_ins = []
    for (i in window.chart_option) {
      if (!window.chart_option[i] || typeof window.chart_option[i] !== "object") continue;
      window.chart_ins[i] = render_chart(window.chart_option[i]["id"], window.chart_option[i]["option"])
    }

    // 初始化表格
    table.render({
      elem: '#bandwidth-table'
      ,id: 'bandwidth-table'
      ,cols: usageBandwidthTableCols()
      ,data: []
      ,limit: 1000
    });

    table.render({
      elem: '#traffic-table'
      ,id: 'traffic-table'
      ,totalRow: true
      ,cols: usageTrafficTableCols()
      ,data: []
      ,limit: 1000
    });

    // 开始首tab间隔更新
    interval_update()

    element.on('tab(site-usage-tab)', function(data){
      if (!siteUsageStill()) return;
      // resize
      for (i in window.chart_ins) {
        window.chart_ins[i].resize();
      }

      // update
      interval_update()

    });

  });
  
  exports('site-usage-senior', {})
});