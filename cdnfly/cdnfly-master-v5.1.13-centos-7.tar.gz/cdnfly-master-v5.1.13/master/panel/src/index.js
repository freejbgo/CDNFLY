/**

 @Name：layuiAdmin 主入口
 @Author：贤心
 @Site：http://www.layui.com/admin/
 @License：LPPL
    
 */
 
layui.extend({
  setter: 'config' //配置文件
  ,admin: 'lib/admin' //核心模块
  ,view: 'lib/view' //核心模块
  ,veikorI18n: '{/}' + layui.cache.base + 'lib/veikor-i18n'
  ,veikorLocalBatch: '{/}' + layui.cache.base + 'lib/veikor-local-batch'
  ,veikorPage: '{/}' + layui.cache.base + 'lib/veikor-page'
}).define(['setter', 'admin', 'veikorLocalBatch', 'veikorPage', 'layer', 'table'], function(exports){
  var setter = layui.setter
  ,element = layui.element
  ,admin = layui.admin
  ,tabsPage = admin.tabsPage
  ,view = layui.view
  ,veikorPage = layui.veikorPage
  ,layer = layui.layer
  ,table = layui.table
  
  //根据路由渲染页面
  ,renderPage = function(){
    var router = layui.router()
    ,path = router.path
    ,pathURL = admin.correctRouter(router.path.join('/'))

    
    
    //默认读取主页
    if(!path.length) path = [''];
    
    //如果最后一项为空字符，则读取默认文件
    if(path[path.length - 1] === ''){
      path[path.length - 1] = setter.entry;
    }
    
    /*
    layui.config({
      base: setter.base + 'controller/'
    });
    */
    
    //重置状态
    var reset = function(type){
      //renderPage.haveInit && layer.closeAll();
      if(renderPage.haveInit){
        $('.layui-layer').each(function(){
          var othis = $(this),
          index = othis.attr('times');
          if(!othis.hasClass('layui-layim')){
            layer.close(index);
          }
        });
      }
      renderPage.haveInit = true;
      
      $(APP_BODY).scrollTop(0);
      delete tabsPage.type; //重置页面标签的来源类型
    };
    
    //如果路由来自于 tab 切换，则不重新请求视图
    if(tabsPage.type === 'tab'){
      //切换到非主页、或者切换到主页且主页必须有内容。方可阻止请求
      if(pathURL !== '/' || (pathURL === '/' && admin.tabsBody().html())){
        admin.tabsBodyChange(tabsPage.index);
        return reset(tabsPage.type);
      }
    }
    
    //请求视图渲染（必须写入 .layadmin-tabsbody-item，不能写 #LAY_app_body 否则会拆掉 tab 壳，第二次切菜单右侧空白）
    function ensureTabsBodyShell() {
      var tabIndex = tabsPage.index || 0;
      var $tab = admin.tabsBody(tabIndex);
      if ($tab.length) return $tab;
      if (!setter.pageTabs) {
        $(APP_BODY).html('<div class="layadmin-tabsbody-item layui-show"></div>');
        tabsPage.index = 0;
        return admin.tabsBody(0);
      }
      return $tab;
    }
    var pageView = view();
    pageView.container = ensureTabsBodyShell();
    pageView.render(path.join('/')).then(function(res){
      
      //遍历页签选项卡
      var matchTo
      ,tabs = $('#LAY_app_tabsheader>li');
      
      tabs.each(function(index){
        var li = $(this)
        ,layid = li.attr('lay-id');
        
        if(layid === pathURL){
          matchTo = true;
          tabsPage.index = index;
        }
      });
      
      //如果未在选项卡中匹配到，则追加选项卡
      if(setter.pageTabs && pathURL !== '/'){
        if(!matchTo){
          $(APP_BODY).append('<div class="layadmin-tabsbody-item layui-show"></div>');
          tabsPage.index = tabs.length;
          var tabLabel = res.title;
          if (!tabLabel) {
            var i18nTab = layui.veikorI18n;
            tabLabel = (i18nTab && i18nTab.customerI18nActive && i18nTab.customerI18nActive())
              ? i18nTab.t('tab.newPage')
              : '新标签页';
          }
          element.tabAdd(FILTER_TAB_TBAS, {
            title: '<span>'+ tabLabel +'</span>'
            ,id: pathURL
            ,attr: router.href
          });
        }
      }
      
      this.container = admin.tabsBody(tabsPage.index);
      setter.pageTabs || this.container.scrollTop(0); //如果不开启标签页，则跳转时重置滚动条
      
      //定位当前tabs
      element.tabChange(FILTER_TAB_TBAS, pathURL);
      admin.tabsBodyChange(tabsPage.index);
      
    }).done(function(){
      layui.use('common', layui.cache.callback.common);
      $win.on('resize', layui.data.resize);
      
      element.render('breadcrumb', 'breadcrumb');
      function veikorAfterViewRender() {
        var i18n = layui.veikorI18n;
        if (!i18n) return;
        i18n.updateConsoleLangSelect();
        // Full applyConsoleI18n runs on layout/menu load and lang change; per-tab view only needs body copy.
        var tabEl = admin.tabsBody(tabsPage.index);
        var root = tabEl.length ? tabEl[0] : document.getElementById('LAY_app_body');
        i18n.applyBreadcrumbI18n(root);
        if (root) {
          i18n.applyDataI18n(root);
          i18n.refreshSwitchLayTextIn(root);
          if (i18n.refreshLayuiFormTitlesIn) i18n.refreshLayuiFormTitlesIn(root);
        }
        i18n.bindLayuiTabTitleFromBody(pathURL, admin.tabsBody(tabsPage.index));
        if (i18n.applyLayuiFrameworkI18n) i18n.applyLayuiFrameworkI18n();
        if (i18n.triggerActivePageLangScopes) i18n.triggerActivePageLangScopes();
      }
      if (layui.veikorI18n) veikorAfterViewRender();
      else layui.use('veikorI18n', veikorAfterViewRender);

      function veikorBootstrapFormsOnLang() {
        var tab = admin.tabsBody(tabsPage.index);
        if (tab.length && typeof window.veikorRepaintScopedFormControlSkins === 'function') {
          window.veikorRepaintScopedFormControlSkins(tab[0], 'veikor-tab-form');
        } else {
          veikorPage.renderForms(tab, { skipSelect: true, assignFilters: false });
        }
      }
      function veikorBootstrapFormsFull() {
        if (veikorPage && typeof veikorPage.bootTabChrome === 'function') {
          veikorPage.bootTabChrome(admin.tabsBody(tabsPage.index)[0]);
        } else {
          veikorPage.renderForms(admin.tabsBody(tabsPage.index), { skipSelect: true });
        }
      }
      veikorBootstrapFormsFull();
      setTimeout(veikorBootstrapFormsFull, 0);
      setTimeout(veikorBootstrapFormsFull, 500);
      setTimeout(veikorBootstrapFormsFull, 1500);
      setTimeout(veikorBootstrapFormsFull, 2500);
      $(document).off('veikor:lang.veikorForms').on('veikor:lang.veikorForms', veikorBootstrapFormsOnLang);

      //容器 scroll 事件，剔除吸附层
      admin.tabsBody(tabsPage.index).on('scroll', function(){
        var othis = $(this)
        ,elemDate = $('.layui-laydate')
        ,layerOpen = $('.layui-layer')[0];

        //关闭 layDate
        if(elemDate[0]){
          elemDate.each(function(){
            var thisElemDate = $(this);
            thisElemDate.hasClass('layui-laydate-static') || thisElemDate.remove();
          });
          othis.find('input').blur();
        }
        
        //关闭 Tips 层
        layerOpen && layer.closeAll('tips');
      });
    });
    
    reset();
  }
  
  //入口页面
  ,entryPage = function(fn){
    var router = layui.router()
    ,container = view(setter.container)
    ,pathParts = []
    ,joined
    ,pathURL
    ,isIndPage;
    layui.each(router.path || [], function(_, seg){
      if (/^\w+=/.test(seg)) return;
      if (seg !== '') pathParts.push(seg);
    });
    joined = pathParts.join('/');
    pathURL = admin.correctRouter(joined);
    
    //检查是否属于独立页面
    layui.each(setter.indPage, function(index, item){
      if(pathURL === item){
        return isIndPage = true;
      }
    });

    // 登录、注册、找回密码末尾多一个斜杠，或再多一个 index 时，仍走独立页，而不是套上控制台框架
    var authBare = pathURL.replace(/\/+$/, '');
    while (/\/index$/.test(authBare)) authBare = authBare.replace(/\/index$/, '').replace(/\/+$/, '');
    if (authBare === '/user/login' || authBare === '/user/reg' || authBare === '/user/forget') {
      isIndPage = true;
      // correctRouter 会把末尾的 index 当成默认页，但视图文件是 login.html 而不是 login/index.html
      joined = joined.replace(/\/+$/, '');
      while (/\/index$/.test(joined)) joined = joined.replace(/\/index$/, '').replace(/\/+$/, '');
      // 退出登录后残留的 user_type 会让语言切换误走管理员分支而跳过 applyAuthPage
      layui.data(setter.tableName, {key: 'user_type', remove: true});
      // 从控制台退出时语言模块已经在。要马上改回三语标题，不能等下一轮回调，否则标签还停在控制台标题
      if (layui.veikorI18n) layui.veikorI18n.applyAuthPage();
      else layui.use('veikorI18n', function(){ layui.veikorI18n.applyAuthPage(); });
    }
    
    //将模块根路径设置为 controller 目录
    layui.config({
      base: setter.base + 'controller/'
    });
    
    //独立页面
    if(isIndPage || pathURL === '/user/login'){ //此处单独判断登入页，是为了兼容旧版（即未在 config.js 配置 indPage 的情况）
      container.render(joined).done(function(){
        admin.pageType = 'alone';
      });
    } else { //后台框架页面
      
      //强制拦截未登入
      if(setter.interceptor){
        var local = layui.data(setter.tableName);
        if(!local[setter.request.tokenName]){
          if (pathURL == "/") {
            return location.hash = '/user/login'
          }
          return location.hash = '/user/login/redirect='+ encodeURIComponent(pathURL); //跳转到登入页
        }
      }

      // 从登录页进来时语言模块已经在。马上换成控制台标题，不能等框架模板回来，否则标签还停在登录标题
      if (layui.veikorI18n) layui.veikorI18n.applyConsoleTitle();
      else layui.use('veikorI18n', function(){ layui.veikorI18n.applyConsoleTitle(); });
      
      //渲染后台结构
      if(admin.pageType === 'console') { //后台主体页
        renderPage();
      } else { //初始控制台结构
        container.render('layout').done(function(){
          renderPage();
          layui.element.render();
          
          if(admin.screen() < 2){
            admin.sideFlexible();
          }
          admin.pageType = 'console';
        }); 
      }
      
    }
  }
  
  ,APP_BODY = '#LAY_app_body', FILTER_TAB_TBAS = 'layadmin-layout-tabs'
  ,$ = layui.$, $win = $(window);

  if (setter && setter.version) {
    try {
      layui.cache.version = setter.version;
    } catch (eVer) {}
  }

  if (table && !table.__veikorRenderDoneBootstrap) {
    table.__veikorRenderDoneBootstrap = true;
  var __veikorTableRender = table.render;
  table.render = function (opts) {
    opts = opts || {};
    var userDone = opts.done;
    opts.done = function (res, curr, count) {
      if (typeof userDone === 'function') {
        userDone.apply(this, arguments);
      }
      setTimeout(function () {
        try {
          var body = document.getElementById('LAY_app_body');
          if (!body) return;
          var root = body.querySelector('.layadmin-tabsbody-item.layui-show') || body;
          if (window.veikorBootTabChrome) {
            window.veikorBootTabChrome(root);
          } else if (window.veikorScheduleFormBootstrap) {
            window.veikorScheduleFormBootstrap(root);
          }
        } catch (eTbl) {}
      }, 0);
    };
    return __veikorTableRender.call(table, opts);
  };
  }

  /** Re-bootstrap Layui form skins when user returns to an existing tab (view is not re-fetched). */
  function veikorRepaintActiveTabForms(index) {
    var tab = admin.tabsBody(index == null ? tabsPage.index : index);
    if (!tab || !tab.length) return;
    function run() {
      try {
        if (veikorPage && typeof veikorPage.bootTabChrome === 'function') {
          veikorPage.bootTabChrome(tab[0]);
        } else if (typeof window.veikorRepaintScopedFormControlSkins === 'function') {
          window.veikorRepaintScopedFormControlSkins(tab[0], 'veikor-tab-form');
        } else if (veikorPage && veikorPage.renderForms) {
          veikorPage.renderForms(tab, { skipSelect: true, assignFilters: false });
        }
      } catch (e) {}
    }
    run();
    setTimeout(run, 0);
    setTimeout(run, 120);
    setTimeout(run, 500);
    setTimeout(run, 1500);
  }

  if (layer && !layer.__veikorOpenPatched) {
    layer.__veikorOpenPatched = true;
    var __veikorLayerOpen = layer.open;
    layer.open = function (options) {
      options = options || {};
      var userSuccess = options.success;
      options.success = function (layero, index) {
        if (typeof userSuccess === 'function') {
          userSuccess.apply(this, arguments);
        }
        if (options.type === 1 && typeof window.veikorScheduleFormBootstrap === 'function') {
          window.veikorScheduleFormBootstrap(layero);
        }
      };
      return __veikorLayerOpen.call(layer, options);
    };
  }

  function veikorOnLayuiTabPanel($show, tabFilter) {
    if (!$show || !$show.length) return;
    if (typeof window.veikorScheduleFormBootstrap === 'function') {
      window.veikorScheduleFormBootstrap($show[0]);
    }
    if (typeof window.veikorReinitSelect2InScope === 'function') {
      window.veikorReinitSelect2InScope($show[0]);
    }
    try {
      var i18n = layui.veikorI18n;
      if (i18n && i18n.customerI18nActive && i18n.customerI18nActive()) {
        i18n.applyDataI18n($show[0]);
        if (i18n.refreshLayuiFormTitlesIn) i18n.refreshLayuiFormTitlesIn($show[0]);
      }
    } catch (eTab) {}
    try {
      $(document).trigger('veikor:layui-tab', [$show[0], tabFilter || '']);
    } catch (eEv) {}
  }

  $(document).off('click.veikorTabForms', '.layui-tab-title li').on('click.veikorTabForms', '.layui-tab-title li', function () {
    var $tab = $(this).closest('.layui-tab');
    var tabFilter = $tab.attr('lay-filter') || '';
    setTimeout(function () {
      var $show = $tab.children('.layui-tab-content').children('.layui-tab-item.layui-show');
      veikorOnLayuiTabPanel($show, tabFilter);
    }, 80);
  });

  if (!element.__veikorTabHookPatched) {
    element.__veikorTabHookPatched = true;
    var __veikorElementOn = element.on;
    element.on = function (filter, callback) {
      if (typeof filter === 'string' && filter.indexOf('tab(') === 0) {
        var m = filter.match(/^tab\(([^)]+)\)$/);
        var tabFilter = m ? m[1] : '';
        return __veikorElementOn.call(this, filter, function (data) {
          if (typeof callback === 'function') callback.apply(this, arguments);
          setTimeout(function () {
            if (typeof window.veikorAfterLayuiTabShown === 'function') {
              window.veikorAfterLayuiTabShown(tabFilter);
            }
          }, 50);
        });
      }
      return __veikorElementOn.apply(this, arguments);
    };
    var __veikorTabChange = element.tabChange;
    element.tabChange = function (filter, id) {
      var ret = __veikorTabChange.apply(this, arguments);
      setTimeout(function () {
        if (typeof window.veikorAfterLayuiTabShown === 'function') {
          window.veikorAfterLayuiTabShown(filter);
        }
      }, 80);
      return ret;
    };
  }

  if (!admin.__veikorPopupFormsPatched) {
    admin.__veikorPopupFormsPatched = true;
    var __veikorAdminPopup = admin.popup;
    admin.popup = function (options) {
      options = options || {};
      var userSuccess = options.success;
      options.success = function (layero, index) {
        if (typeof userSuccess === 'function') {
          userSuccess.apply(this, arguments);
        }
        if (typeof window.veikorScheduleFormBootstrap === 'function') {
          window.veikorScheduleFormBootstrap(layero);
        }
      };
      return __veikorAdminPopup.call(admin, options);
    };
  }

  if (!admin.__veikorTabsBodyChangePatched) {
    admin.__veikorTabsBodyChangePatched = true;
    var __veikorTabsBodyChange = admin.tabsBodyChange;
    admin.tabsBodyChange = function (index) {
      __veikorTabsBodyChange.call(admin, index);
      veikorRepaintActiveTabForms(index);
    };
  }

  //初始主体结构
  layui.link(
    setter.base + 'style/admin.css?v=' + (setter.version || admin.v)
    ,function(){
      entryPage()
    }
    ,'layuiAdmin'
  );
  
  //监听Hash改变
  window.onhashchange = function(){
    entryPage();
     //执行 {setter.MOD_NAME}.hash 下的事件
    layui.event.call(this, setter.MOD_NAME, 'hash({*})', layui.router());
  };
  
  //扩展 lib 目录下的其它模块
  layui.each(setter.extend, function(index, item){
    var mods = {};
    mods[item] = '{/}' + setter.base + 'lib/extend/' + item;
    layui.extend(mods);
  });

  (function veikorWatchDynamicForms() {
    if (!window.MutationObserver || admin.__veikorFormObserver) return;
    admin.__veikorFormObserver = true;
    var debounce = null;
    var body = document.getElementById('LAY_app_body');
    if (!body) return;
    function addedNodesNeedFormBootstrap(records) {
      var i;
      var j;
      var nodes;
      var n;
      for (i = 0; i < records.length; i++) {
        nodes = records[i].addedNodes;
        if (!nodes || !nodes.length) continue;
        for (j = 0; j < nodes.length; j++) {
          n = nodes[j];
          if (!n || n.nodeType !== 1) continue;
          if (
            n.classList &&
            (n.classList.contains('layui-form') ||
              n.classList.contains('layui-table-tool') ||
              n.tagName === 'SELECT' ||
              n.tagName === 'INPUT')
          ) {
            return true;
          }
          if (n.querySelector && n.querySelector('.layui-form, select, input, .layui-table-tool')) {
            return true;
          }
        }
      }
      return false;
    }

    var obs = new MutationObserver(function (records) {
      if (!addedNodesNeedFormBootstrap(records)) return;
      clearTimeout(debounce);
      debounce = setTimeout(function () {
        try {
          var tab = body.querySelector('.layadmin-tabsbody-item.layui-show');
          var root = tab || body;
          if (window.veikorBootTabChrome) {
            window.veikorBootTabChrome(root);
          } else if (window.veikorScheduleFormBootstrap) {
            window.veikorScheduleFormBootstrap(root);
          }
        } catch (eDyn) {}
      }, 600);
    });
    obs.observe(body, { childList: true, subtree: true });
  })();

  //对外输出
  exports('index', {
    render: renderPage
  });
});
