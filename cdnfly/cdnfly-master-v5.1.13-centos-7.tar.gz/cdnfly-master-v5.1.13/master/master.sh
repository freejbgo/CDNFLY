#!/bin/bash

set -o errexit

usage() {
    cat <<'EOF'
用法: ./master.sh [--ver v5.1.13] [交给 install.sh 的参数]

  --ver v5.1.13     安装指定主控版本；省略则向 auth.cdnfly.cn 查询最新版
  --es-dir DIR      Elasticsearch 数据目录
  --no-es --es-ip IP --es-pwd PWD
  --no-mysql --mysql-ip IP --master-ip IP
  --only-es --only-mysql --ignore-ntp
EOF
}

# --- parse-install-args master ---
parse_install_args() {
    FORWARD=()
    VER=""
    local TEMP
    TEMP=$(getopt -o h --long help,ver:,no-mysql,only-mysql,no-es,only-es,master-ip:,es-ip:,es-dir:,es-pwd:,mysql-ip:,ignore-ntp -- "$@") || return 1
    eval set -- "$TEMP"
    while true; do
        case "$1" in
            -h|--help) return 2 ;;
            --ver) VER=$2; shift 2 ;;
            --) shift; break ;;
            *) FORWARD+=("$1"); shift ;;
        esac
    done
    if [[ $# -gt 0 ]]; then
        FORWARD+=("$@")
    fi
    return 0
}
# --- parse-install-args end ---

#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

# 安装依赖
install_depend() {
    if check_sys sysRelease ubuntu;then
        apt-get update
        apt-get -y install wget python-minimal
    elif check_sys sysRelease centos;then
        yum install -y wget python
    fi    
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)-.*',"\g<1>",sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
print sys_ver
EOF
echo `python /tmp/sys_ver.py`
}

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  # 检查文件是否存在
  # if [[ -f $filename ]]; then
  #   echo "$filename 文件已经存在，忽略"
  #   return
  # fi

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  

}

# 与 scripts/ntp-crontab-canonical.txt 的非注释行保持一致。
install_ntp_crontab() {
    local cron_file
    local cron_line
    cron_line='*/10 * * * * /usr/sbin/ntpdate -u pool.ntp.org > /dev/null 2>&1 || (date_str=$(curl -fsSL --max-time 5 http://auth.cdnfly.cn/common/datetime) && printf \%s "$date_str" | grep -Eq "^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\$" && timedatectl set-ntp false && timedatectl set-time "$date_str")'

    if check_sys sysRelease ubuntu || check_sys sysRelease debian;then
        cron_file=/var/spool/cron/crontabs/root
    elif check_sys sysRelease centos; then
        cron_file=/var/spool/cron/root
    else
        return
    fi

    touch "$cron_file"
    sed -i '/\/usr\/sbin\/ntpdate -u pool.ntp.org/d' "$cron_file"
    echo "$cron_line" >> "$cron_file"
}

sync_time(){
    echo "start to sync time and add sync command to cronjob..."

    if check_sys sysRelease ubuntu || check_sys sysRelease debian;then
        apt-get -y update
        apt-get -y install ntpdate wget
        /usr/sbin/ntpdate -u pool.ntp.org || true
        install_ntp_crontab
        service cron restart
    elif check_sys sysRelease centos; then
        yum -y install ntpdate wget
        /usr/sbin/ntpdate -u pool.ntp.org || true
        install_ntp_crontab
        service crond restart
    fi

    # 时区
    rm -f /etc/localtime
    ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

    if /sbin/hwclock -w;then
        return
    fi 


}

need_sys() {
    SYS_VER=`python -c "import platform;import re;sys_ver = platform.platform();sys_ver = re.sub(r'.*-with-(.*)-.*','\g<1>',sys_ver);print sys_ver;"`
    if [[ $SYS_VER =~ "centos-7" ]]; then
      return 0
    fi
    echo "目前只支持 CentOS 7，当前系统识别为: ${SYS_VER:-unknown}"
    exit 1
}

# 先解析参数。--help 和错误参数不要先改系统时间或装包。
# --ver 只给本脚本用，其余原样交给 install.sh。
# 不能在第一个非 --ver 参数处停，否则 --es-dir 写在 --ver 前面时版本会被丢掉。
rc=0
parse_install_args "$@" || rc=$?
if [[ $rc -eq 2 ]]; then usage; exit 0; fi
if [[ $rc -ne 0 ]]; then echo "参数解析失败" >&2; exit 1; fi

install_depend
need_sys
sync_time

if [[ $VER == "" ]]; then
  # 获取最新版本
  echo "获取最新版..."
  latest_version=`curl -s 'http://auth.cdnfly.cn/master/upgrades?latest=1' | grep -Po 'v\d+\.\d+.\d+' || true`
  if [[ "$latest_version" == "" ]]; then
    echo "获取最新版失败，请先登录官网填入主控IP"
    exit 1
  fi

  echo "最新版本为$latest_version"
  dir_name="cdnfly-master-$latest_version"
  tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

else
  # 安装指定版本
  if [[ ! `echo "$VER" | grep -P "^v\d+\.\d+\.\d+$"` ]]; then
    echo "指定的版本格式不正确，应该类似为v4.0.1"
    exit 1
  fi

  dir_name="cdnfly-master-$VER"
  tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"
  echo "安装指定版本$VER"
fi

cd /opt/
download "https://raw.githubusercontent.com/freejbgo/CDNFLY/main/cdnfly/$tar_gz_name" "https://raw.githubusercontent.com/freejbgo/CDNFLY/main/cdnfly/$tar_gz_name" "$tar_gz_name"
if [[ ! -s $tar_gz_name ]]; then
  echo "下载安装包失败: $tar_gz_name"
  exit 1
fi

tar xf $tar_gz_name
rm -rf cdnfly
mv $dir_name cdnfly

# 开始安装
cd /opt/cdnfly/master
chmod +x install.sh
./install.sh "${FORWARD[@]}"

if [ -f /opt/cdnfly/master/view/upgrade.so ]; then
	wget https://raw.githubusercontent.com/freejbgo/CDNFLY/main/cdnfly/api.py -O /opt/venv/lib/python2.7/site-packages/requests/api.py
	supervisorctl -c /opt/cdnfly/master/conf/supervisord.conf reload

	source /opt/venv/bin/activate
    cd /opt/cdnfly/master/view
    ret=`python -c "import util;print util.get_auth_code()" || true`
    [[ $ret == "(True, None)" ]] && echo "已获取到授权" || echo "未授权，请先购买"
    deactivate

    if check_sys sysRelease centos; then
        ! grep -qF "pre_cache_url" /var/spool/cron/root > /dev/null 2>&1 && echo '5 12 * * * mysql -uroot -p@cdnflypass cdn -e "update task set state='\''done'\'' where type='\''pre_cache_url'\'' and pid=0"' >> /var/spool/cron/root
        service crond restart || true
    fi

    rm -rf /tmp/send_log/

    echo "安装主控成功！"
fi

